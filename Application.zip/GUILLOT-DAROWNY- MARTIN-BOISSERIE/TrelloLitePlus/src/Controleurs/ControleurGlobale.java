package Controleurs;

import javax.swing.*;
import java.io.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import Modeles.*;
import Vues.*;

/**
 * Cette classe ControleurGlobale est le controleur de la vue globale. 
 * Elle permet de réaliser les évènements. 
 * Ici, dans la classe ControleurGlobale permet d'afficher le profil du membre,
 * d'ajouter des participants, de voir les participants, de mettre à jour la vue, 
 * et d'ajouter des tableaux.
 * 
 * @author Estelle BOISSERIE
 **/
public class ControleurGlobale {
	//---------------------------------
	// ATTRIBUTS
	//---------------------------------
	private ModeleProjet Projet;

	private VueGlobale Vue;

	private final static Font POLICETITRE = new Font("Arial", Font.BOLD, 20            );
	private final static Font POLICECORPS = new Font("New Times Romans", Font.PLAIN, 15);

	private final static Color COULEURTHEME = new Color(147, 112, 219);



	//---------------------------------
	// CONSTRUCTEUR
	//---------------------------------
	/**
	 * Constructeur de la classe ControleurGlobale.
	 * Il permet de créer une instance de ControleurGlobale afin de l'utiliser comme écouteur.
	 * 
	 * @param projet Le projet affiché
	 * @param vue La vue du projet
	 **/
	public ControleurGlobale(ModeleProjet projet, VueGlobale vue) {
		Projet = projet;
		Vue = vue;
	}



	//---------------------------------
	// METHODES
	//---------------------------------
	/**
	 * Afficher le profil du membre en charge du profil
	 **/
	public void afficherProfil() {
		// Créer la fenetre du profil du membre
		JFrame fnrProfil = new JFrame("Compte");

		// Cliquer sur la croix de la fenêtre ferme celle-ci
		fnrProfil.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		// Créer le fichier de sérialisation
		File Fichier = new File ("membres.dat");

		//Récupérer les participants
		ModeleMembre createur = Projet.getCreateurProjet();

		// Créer une vue du profil du membre
		VueMembre Profil = new VueMembre(Projet.getCreateurProjet());

		// Créer une vue pour les modification du profil du membre
		VueMembreModifie ProfilModifie = new VueMembreModifie(Projet.getCreateurProjet());

		// Créer un controleur du membre
		ControleurMembre ecouteurMembre = new ControleurMembre(Projet.getCreateurProjet(), Profil, ProfilModifie);

		// Sérialisation
		// Si le fichier de sérialisation n'existe pas
		/*if (!Fichier.exists()) {
			System.out.println ("Le fichier favoris.dat n'existe pas !");
			// Serialiser l'objet favoris : on le transforme en une SERIE d'octets qu'on écrit sur disque
			System.out.println ("Enregistrement de l'objet favoris sur disque");
			FileOutputStream fichier = new FileOutputStream("membres.dat");
			ObjectOutputStream flotObjet = new ObjectOutputStream(fichier);
			flotObjet.writeObject(Projet.getMembres());
			flotObjet.close();
		} 
		else {
			// Si le fichier favoris.dat existe déjà
			System.out.println ("Le fichier favoris.dat existe !");
			FileInputStream fichier = new FileInputStream("membres.dat");
			ObjectInputStream flotObjet = new ObjectInputStream(fichier);
			createur = (ModeleMembre) (flotObjet.readObject());
			flotObjet.close();;
		}
		 */

		// Execution des boutons
		/**
		 * Cliquer sur le bouton "Modifier"
		 **/
		Profil.btnModifierClick(new ActionListener() {
			/**
			 * Evènement quand on clique
			 * @param e Evènement
			 **/
			public void actionPerformed(ActionEvent e) {
				ecouteurMembre.modifierProfil();
			}
		});
		/**
		 * Cliquer sur le bouton "Rafraîchir"
		 **/
		Profil.btnRafraichirClick(new ActionListener() {
			/**
			 *  Evènement quand on clique
			 * @param e Evènement
			 **/
			public void actionPerformed(ActionEvent e) {
				ecouteurMembre.rafraichir();
			}
		});
		/**
		 * Cliquer sur le bouton "Voir mes commentaires"
		 **/
		Profil.btnCommentaireClick(new ActionListener() {
			/**
			 *  Evènement quand on clique
			 * @param e Evènement
			 **/
			public void actionPerformed(ActionEvent e) {
				ecouteurMembre.voirCommentaire();
			}
		});
		/**
		 * Cliquer sur le bouton "Voir mes projets"
		 **/
		Profil.btnProjetClick(new ActionListener() {
			/**
			 *  Evènement quand on clique
			 * @param e Evènement
			 **/
			public void actionPerformed(ActionEvent e) {
				ecouteurMembre.voirProjet();
			}
		});
		/**
		 *Cliquer sur le bouton "Modifier"
		 **/
		Profil.btnCarteClick(new ActionListener() {
			/**
			 *  Evènement quand on clique
			 * @param e Evènement
			 **/
			public void actionPerformed(ActionEvent e) {
				ecouteurMembre.voirCarte();
			}
		});
		/**
		 *Cliquer sur le bouton "Sauvegarde"
		 **/
		ProfilModifie.btnSauvegardeClick(new ActionListener() {
			/**
			 *  Evènement quand on clique
			 * @param e Evènement
			 **/
			public void actionPerformed(ActionEvent e) {
				ecouteurMembre.enregistrement();
			}
		});
		/**
		 *Cliquer sur le bouton "Modifier"
		 **/
		ProfilModifie.btnPhotoClick(new ActionListener() {
			/**
			 *  Evènement quand on clique
			 * @param e Evènement
			 **/
			public void actionPerformed(ActionEvent e) {
				ecouteurMembre.changerPhoto();
			}
		});

		// Ajouter la vue à la fenêtre
		fnrProfil.add(Profil);

		// Adapter la taille de la fenêtre
		fnrProfil.pack();

		// Centrer la fenêtre
		fnrProfil.setLocationRelativeTo(null); 

		// Afficher la fenêtre
		fnrProfil.setVisible(true);
	}


	/**
	 * Ajouter des participants
	 **/
	public void ajouterParticipant() {
		// Créer la fenetre permettant de voir les membres disponibles
		JFrame fnrParticipant = new JFrame("Les personnes possibles");

		// Cliquer sur la croix de la fenêtre ferme celle-ci
		fnrParticipant.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);


		// Créer un label titre
		JLabel lblPermission = new JLabel("Donnez-vous la permission au membre d'agir sur le projet ?");

		// Créer un checkbox pour donner la permission
		JCheckBox ChoixOui = new JCheckBox("Donner la permission");

		// Créer un checkbox pour ne pas donner la permission
		JCheckBox ChoixNon = new JCheckBox("Ne pas donner la permission");


		// Créer un bouton ajouter
		JButton btnAjouter = new JButton("Ajouter");


		// Créer un panel contenant les check box
		JPanel pnlChoix = new JPanel(new GridLayout(1, 2));

		// Mise en page
		fnrParticipant.setLayout(new GridLayout(1, 2));

		// Appliquer la couleur
		btnAjouter.setBackground(COULEURTHEME);

		// Appliquer le style de police
		btnAjouter.setFont(POLICETITRE);
		lblPermission.setFont(POLICETITRE);
		pnlChoix.setFont(POLICECORPS);

		// Ajouter le bouton à la fenêtre principale
		fnrParticipant.add(btnAjouter);

		// Ajouter à la fenêtre de permission
		pnlChoix.add(ChoixOui);
		pnlChoix.add(ChoixNon);

		// Créer des membres
		ModeleMembre membre = new ModeleMembre("Boisserie", "Estelle", "mdp", "estelle.boisserie@universite-paris-saclay.fr");
		ModeleMembre membre2 = new ModeleMembre("Martin", "Cathy", "MDP", "cathy.martin@universite-paris-saclay.fr");
		ModeleMembre membre3 = new ModeleMembre("Guillot", "Antonin", "motdepasse", "antonin.guillot@universite-paris-saclay.fr");
		ModeleMembre membre4 = new ModeleMembre("Darowny", "Corentin", "MotDePasse", "corentin.darowny@universite-paris-saclay.fr");

		// Créer une liste des modèles de membres
		ArrayList<ModeleMembre> Membres = new ArrayList<ModeleMembre>();
		Membres.add(membre);
		Membres.add(membre2);
		Membres.add(membre3);
		Membres.add(membre4);

		// Créer une liste des noms et prénoms des membres
		DefaultListModel<String> membres = new DefaultListModel<String>();
		membres.addElement(membre.getNomMembre() + " " + membre.getPrenomMembre());
		membres.addElement(membre2.getNomMembre() + " " + membre2.getPrenomMembre());
		membres.addElement(membre3.getNomMembre() + " " + membre3.getPrenomMembre());
		membres.addElement(membre4.getNomMembre() + " " + membre4.getPrenomMembre());

		// Ajouter les membres à la liste
		JList<String> lstMembre = new JList<String>(membres);

		// Ajouter à la vue principale
		fnrParticipant.add(lstMembre);

		lstMembre.addListSelectionListener(new ListSelectionListener() {
			/**
			 * Changement de valeur
			 * @param e Evènement
			 **/
			public void valueChanged(ListSelectionEvent e) {
				// Si élément sélectionné
				if (!e.getValueIsAdjusting()) {
					// Obtenir l'élément sélectionné
					String ElementSelectionne = lstMembre.getSelectedValue();
					// Obtenir l'indice de l'élément sélectionné
					int indice = lstMembre.getSelectedIndex();

					// Mettre un écouteur au bouton
					btnAjouter.addActionListener(new ActionListener() {
						/**
						 * Cliquer sur le bouton "Ajouter"
						 * @param e Evènement
						 **/
						public void actionPerformed(ActionEvent e) {
							// Si la sélection n'est pas nulle
							if (lstMembre.getSelectedValue() != null) {
								// Récupérer le modèle membre choisi
								ModeleMembre membreSelectionne = Membres.get(indice);

								// Créer une fenêtre de dialogue pour attribuer les permissions
								JFrame fnrPermission = new JFrame("Choix de la permission");
								//Cliquer sur la croix ferme la fenetre
								fnrPermission.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
								//Créer un panel 
								JPanel pnlGeneral = new JPanel(new GridLayout(2,1));
								//Ajouter à la fenêtre de dialogue
								pnlGeneral.add(lblPermission);
								pnlGeneral.add(pnlChoix);
								fnrPermission.add(pnlGeneral);
								// Mettre une taille
								fnrPermission.pack();
								// Centrer la fenêtre
								fnrPermission.setLocationRelativeTo(null);
								// Rendre la fenêtre `fnrPermission` visible
								fnrPermission.setVisible(true);

								// Ajouter un écouteur d'événements à la case à cocher "Donner la permission"
								ChoixOui.addItemListener(new ItemListener() {
									/**
									 * La valeur de la check box a changé.
									 * @param e Evènement
									 **/
									public void itemStateChanged(ItemEvent e) {
										//Si la case est sélectionnée
										if (e.getStateChange() == ItemEvent.SELECTED) {
											// Afficher une fenêtre de dialogue
											int Reponse = JOptionPane.showConfirmDialog(null,
													"Souhaitez vous donner la permission à " + ElementSelectionne + " sur votre projet " + Projet.getNomProjet() + "?",
													"Confirmation", JOptionPane.YES_NO_OPTION);
											// Si le membre valide ses choix
											if (Reponse == JOptionPane.YES_OPTION) {
												for (int i=0; i<Membres.size(); i++) {
													if (Membres.get(i) == membreSelectionne) {
														// Fermer la fenêtre de dialogue
														fnrPermission.dispose();
														// Créer une participation 
														ModelePrend_par participation = new ModelePrend_par(Projet , Membres.get(i) , true);
													}
												}

											}
										}
									}
								});

								// Ajouter un écouteur d'événements à la case à cocher "Ne pas donner la permission"
								ChoixNon.addItemListener(new ItemListener() {
									/**
									 * La valeur de la check box a changé.
									 * @param e Evènement
									 **/
									// Si la case est sélectionnée
									public void itemStateChanged(ItemEvent e) {
										if (e.getStateChange() == ItemEvent.SELECTED) {
											// Afficher une fenêtre de dialogue
											int Reponse = JOptionPane.showConfirmDialog(null,
													"Souhaitez vous ne pas donner la permission à " + ElementSelectionne + " sur votre projet " + Projet.getNomProjet() + "?",
													"Confirmation", JOptionPane.YES_NO_OPTION);
											// Si le membre valide ses choix
											if (Reponse == JOptionPane.YES_OPTION) {
												for (int i=0; i<Membres.size(); i++) {
													if (Membres.get(i) == membreSelectionne) {
														// Fermer la fenêtre de dialogue
														fnrPermission.dispose();
														// Créer une participation 
														ModelePrend_par participation = new ModelePrend_par(Projet , Membres.get(i) , false);

													}
												}

											}
										}
									}
								});
							}
						}
					});
				}
			}
		});


		// Mettre une taille
		fnrParticipant.pack();


		// Centrer la fenêtre
		fnrParticipant.setLocationRelativeTo(null);

		// Afficher la fenêtre
		fnrParticipant.setVisible(true);
	}



	/**
	 * Mettre à jour la vue
	 **/
	public void restructure() {
		Vue.miseAJourPhoto();
	}


	/**
	 * Ajouter un tableau
	 **/
	public void ajouterTableau() {
		// Créer une fenêtre de dialogue
		JDialog fnrAjouterTableau = new JDialog();

		// Créer un label
		JLabel lblTitre = new JLabel("Comment souhaitez vous intitulez votre tableau ?");

		// Créer une saisie de texte 
		JTextField txtTitre = new JTextField(20);

		// Créer un bouton 
		JButton btnCreer = new JButton("Créer");

		// Créer un panel
		JPanel pnlTitre = new JPanel(new GridLayout(1,2));

		// Appliquer le style de police
		lblTitre.setFont(POLICETITRE);
		btnCreer.setFont(POLICETITRE);

		// Appliquer la couleur 
		btnCreer.setBackground(COULEURTHEME);

		// Mettre un écouteur au bouton
		btnCreer.addActionListener(new ActionListener() {
			/**
			 * Cliquer sur le bouton "Creer".
			 * @param e Evènement
			 **/
			public void actionPerformed(ActionEvent e) {
				// Afficher une fenêtre de dialogue
				int Reponse = JOptionPane.showConfirmDialog(null,
						"Souhaitez vous ajouter le tableau " + txtTitre.getText() + "?",
						"Confirmation", JOptionPane.YES_NO_OPTION);
				// Si le membre valide ses choix
				if (Reponse == JOptionPane.YES_OPTION) {
					// Enregistrement du titre
					ModeleTableau NouveauTableau = new ModeleTableau(txtTitre.getText());
					// Ajouter le tableau au projet 
					Projet.ajouterTableau(NouveauTableau);
					// Ajouter à la vue
					Vue.miseAJourTableau(NouveauTableau);
					// Fermer la fenêtre après l'ajout
					fnrAjouterTableau.dispose(); 
				}
			}

		});

		// Ajouter à la fênetre de dialogue
		pnlTitre.add(lblTitre);
		pnlTitre.add(txtTitre);
		fnrAjouterTableau.setLayout(new GridLayout(2,1));
		fnrAjouterTableau.add(pnlTitre);
		fnrAjouterTableau.add(btnCreer);

		// Mettre un titre à la fenêtre 
		fnrAjouterTableau.setTitle("Création de tableau");

		// Mettre une taille
		fnrAjouterTableau.pack();

		// Bloquer l'interaction avec la fenêtre principale
		fnrAjouterTableau.setModal(true);

		// Centrer la fenêtre
		fnrAjouterTableau.setLocationRelativeTo(null);

		// Afficher la fenêtre
		fnrAjouterTableau.setVisible(true);
	}



	/**
	 * Voir les participants du projet
	 */
	public void voirParticipant() {
		// Créer une fenêtre de dialogue
		JFrame fnrParticipant = new JFrame("Les participants");

		// Cliquer sur la croix de la fenêtre ferme celle-ci
		fnrParticipant.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		// Mise en page de la fenêtre 
		fnrParticipant.setLayout(new GridLayout(1,2));

		// Créer une liste des modèles de participants
		ArrayList<ModeleMembre> Participants = new ArrayList<ModeleMembre>();

		// Créer une liste des noms et prénoms des participants et leur permission
		DefaultListModel<String> participants = new DefaultListModel<String>();

		// Créer un bouton
		JButton btnModifierPermission = new JButton("Modifier la permission");

		// Créer un panel pour contenir les participants et leurs rôles
		JPanel pnlParticipant = new JPanel(new GridLayout(1,2));

		// Appliquer le style de police
		btnModifierPermission.setFont(POLICETITRE);

		// Appliquer la couleur
		btnModifierPermission.setBackground(COULEURTHEME);

		// Pour chaque participant du projet
		for (int i = 0; i <= Projet.getMembres().size(); i++) {
			participants.addElement(Projet.getMembres().get(i).getNomMembre() + " " + Projet.getMembres().get(i).getPrenomMembre() +
					" " + Projet.getParticipation().get(i).getPermissionCollabore() + "\n");
			Participants.add(Projet.getMembres().get(i));
		}


		// Ajouter les membres à la liste
		JList<String> lstParticipant = new JList<String>(participants);

		// Appliquer le style de police 
		lstParticipant.setFont(POLICECORPS);

		//Ajouter au panel
		pnlParticipant.add(lstParticipant);
		pnlParticipant.add(btnModifierPermission);

		// Ajouter à la fenêtre
		fnrParticipant.add(pnlParticipant);

		// Ajouter un écouteur à la liste,
		lstParticipant.addListSelectionListener(new ListSelectionListener() {
			/**
			 * La valeur de l'élément sélectionné a changé.
			 * @param e Evènement
			 **/
			public void valueChanged(ListSelectionEvent e) {
				// Si élément séléctionné
				if (!e.getValueIsAdjusting()) {
					// Obtenir l'élément sélectionné
					String ElementSelectionne = lstParticipant.getSelectedValue();
					// Obtenir l'indice de l'élément sélectionné
					int indice = lstParticipant.getSelectedIndex();

					// Mettre un écouteur au bouton
					btnModifierPermission.addActionListener(new ActionListener() {
						/**
						 * Quand on clique sur le bouton "Modifier la permission".
						 * @param e Evènement
						 **/
						public void actionPerformed(ActionEvent e) {
							// Si la sélection n'est pas nulle
							if (indice >= 0 && indice < Participants.size()) {
								//Recuperer le modele membre choisit
								ModeleMembre participantSelectionne = Participants.get(indice);

								// Créer une fenêtre de dialogue pour attribuer les permissions
								JFrame fnrPermission = new JFrame("Gestion des permissions");
								// Cliquer sur la croix de la fenêtre ferme celle-ci
								fnrPermission.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
								// Mise en page 
								fnrPermission.setLayout(new GridLayout(2,1));
								// Créer un label titre 
								JLabel lblPermission = new JLabel("Donnez-vous la permission au membre d'agir sur le projet ?");
								// Créer un checkbox pour donner la permission
								JCheckBox ChoixOui = new JCheckBox("Donner la permission");
								// Créer un checkbox pour ne pas donner la permission
								JCheckBox ChoixNon = new JCheckBox("Ne pas donner la permission");
								// Créer un panel contenant les check box
								JPanel pnlChoix = new JPanel(new GridLayout(1,2));
								//Appliquer le style de police
								lblPermission.setFont(POLICETITRE);
								pnlChoix.setFont(POLICECORPS);
								//Ajouter à la fenêtre de permission
								pnlChoix.add(ChoixOui);
								pnlChoix.add(ChoixNon);
								// Ajouter à la fenêtre
								fnrPermission.add(lblPermission);
								fnrPermission.add(pnlChoix);
								// Mettre une taille
								fnrPermission.pack();
								// Centrer la fenêtre
								fnrPermission.setLocationRelativeTo(null);
								// Rendre la fenêtre `fnrPermission` visible
								fnrPermission.setVisible(true);

								// Ajouter un écouteur d'événements à la case à cocher "Donner la permission"
								ChoixOui.addItemListener(new ItemListener() {
									/**
									 * La valeur de la chack box a changé.
									 * @param e Evènement
									 **/
									public void itemStateChanged(ItemEvent e) {
										//Si la case est sélectionnée
										if (e.getStateChange() == ItemEvent.SELECTED) {
											// Afficher une fenêtre de dialogue
											int Reponse = JOptionPane.showConfirmDialog(null,
													"Souhaitez vous modifier la permission de " + ElementSelectionne + " sur votre projet " + Projet.getNomProjet() + "?",
													"Confirmation", JOptionPane.YES_NO_OPTION);
											// Si le membre valide ses choix
											if (Reponse == JOptionPane.YES_OPTION) {
												for (int i=0; i<Participants.size(); i++) {
													if (Projet.getParticipation().get(i).getMembre() == participantSelectionne) {
														// Modifier la permission
														Projet.getParticipation().get(i).setPermissionCollabore(true);
														// Fermer la fenêtre de dialogue
														fnrPermission.dispose();
														participants.setElementAt(Projet.getParticipation().get(i).getParticipant(), i);
														ModeleMembre membre = Projet.getMembres().get(i);
														Participants.add(membre);
														lstParticipant.repaint();
													}
													else { 
														// Afficher une erreure
														JOptionPane.showMessageDialog(null, "ERREUR: Le participant est introubale.", "Avertissement",
																JOptionPane.WARNING_MESSAGE);
													}
												}

											}
										}
									}
								});

								// Ajouter un écouteur d'événements à la case à cocher "Ne pas donner la permission"
								ChoixNon.addItemListener(new ItemListener() {
									/**
									 * La valeur de la check box a changé.
									 * @param e Evènement
									 **/
									// Si la case est sélectionnée
									public void itemStateChanged(ItemEvent e) {
										if (e.getStateChange() == ItemEvent.SELECTED) {
											// Afficher une fenêtre de dialogue
											int Reponse = JOptionPane.showConfirmDialog(null,
													"Souhaitez vous modifier la permission de " + ElementSelectionne + " sur votre projet " + Projet.getNomProjet() + "?",
													"Confirmation", JOptionPane.YES_NO_OPTION);
											// Si le membre valide ses choix
											if (Reponse == JOptionPane.YES_OPTION) {
												for (int i=0; i<Participants.size(); i++) {
													if (Projet.getParticipation().get(i).getMembre() == participantSelectionne) {
														// Modifier la permission
														Projet.getParticipation().get(i).setPermissionCollabore(false);
														// Fermer la fenêtre de dialogue
														fnrPermission.dispose();
														// Ajouter la participation
														participants.setElementAt(Projet.getParticipation().get(i).getParticipant(), i);
														ModeleMembre membre = Projet.getMembres().get(i);
														Participants.add(membre);
														// Rafraîchir la liste
														lstParticipant.repaint();

													}
													else { 
														// Afficher une erreure
														JOptionPane.showMessageDialog(null, "ERREUR: Le participant est introubale.", "Avertissement",
																JOptionPane.WARNING_MESSAGE);
													}
												}

											}
										}
									}
								});
							}
						}
					});
				}
			}
		});

		// Ajouter à la fenêtre principale
		fnrParticipant.add(lstParticipant);

		// Mettre un titre à la fenêtre 
		fnrParticipant.setTitle("Liste des participants");

		// Mettre une taille
		fnrParticipant.pack();

		// Centrer la fenêtre
		fnrParticipant.setLocationRelativeTo(null);

		// Afficher la fenêtre
		fnrParticipant.setVisible(true);
	}
}