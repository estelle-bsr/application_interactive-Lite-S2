package Controleurs;

import java.awt.event.*;
import javax.swing.*;
import Modeles.*;
import Vues.*;

/**
 * 
 *
 *         La classe ControleurListe gère la modification d'une liste et la
 *         création de cartes.
 *         Elle affiche les vues de modification de liste et de création de
 *         carte, et enregistre les choix effectués.
 *         Elle crée également une nouvelle carte et l'affiche dans la liste.
 * @author MARTIN Cathy & DAROWNY Corentin
 */

public class ControleurListe {
	/******************
	 ** ATTRIBUTS **
	 ******************/
	private ModeleListe Liste;
	private VueListe VueInitiale;
	private VueModifierListe VueModifie;
	private VueCreeCarte VueCree;
	private VueCarte vueCarte;
	public JFrame frnListe = new JFrame("Modifier liste");
	private JFrame frnListeCarte = new JFrame("Création carte");

	/**********************
	 ** CONSTRUCTEUR **
	 **********************/

	/**
	 * Constructeur de la classe ControleurListe.
	 * 
	 * @param liste      le modèle de liste
	 * @param vue        la vue de la liste initiale
	 * @param VueModifie la vue de modification de la liste
	 * @param VueCree    la vue de création de carte
	 */
	public ControleurListe(ModeleListe liste, VueListe vue, VueModifierListe VueModifie, VueCreeCarte VueCree) {
		Liste = liste;
		VueInitiale = vue;
		this.VueModifie = VueModifie;
		this.VueCree = VueCree;

		// Ajouter l'écouteur pour le bouton "Créer" de la vue de création de carte
		VueCree.btnCreeClick(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreeCarte();
			}
		});
	}

	/******************
	 ** METHODES **
	 ******************/

	/**
	 * Affiche la vue permettant de créer une carte.
	 * Crée une carte vide, configure la fenêtre et ajoute la vue de création.
	 * 
	 * @return la carte créée
	 */
	public ModeleCarte CreeCarte() {
		// créé une carte vide
		ModeleCarte carte = new ModeleCarte("", "", "00/00/0000");

		// Configurer la fenêtre
		frnListeCarte.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		// Ajouter la vue
		frnListeCarte.getContentPane().add(VueCree);
		// Adapter de la taille de la fenêtre
		frnListeCarte.pack();
		// Rendre visible la fenêtre
		frnListeCarte.setVisible(true);
		// Vider le JTextField/Area
		VueCree.getTitre().setText("");
		VueCree.getDescription().setText("");
		VueCree.getDateLimite().setText("00/00/0000");
		return carte;
	}

	/**
	 * Affiche la vue permettant de modifier la liste.
	 * Configure la fenêtre et ajoute la vue de modification.
	 */
	public void modifierListe() {
		// Configurer la fenêtre
		frnListe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		// Ajouter la vue
		frnListe.getContentPane().add(VueModifie);
		// Adapter de la taille de la fenêtre
		frnListe.pack();
		// Rendre visible la fenêtre
		frnListe.setVisible(true);
	}

	/**
	 * Enregistre les choix effectués lors de la modification de la liste.
	 * Met à jour le nouveau nom de la liste et le change aussi à la vue initiale.
	 */
	public void enregistrement() {
		// Enregistrer du nouveau nom
		Liste.setNomListe(VueModifie.getTitre());

		// Afficher une fenêtre de dialogue
		int reponse = JOptionPane.showConfirmDialog(null,
				"Confirmez-vous vos modifications ?",
				"Confirmation", JOptionPane.YES_NO_OPTION);
		// Si le membre valide ses choix
		if (reponse == JOptionPane.YES_OPTION) {
			// Fermer la fenêtre
			frnListe.dispose();
			// Mettre à jour la vue de la carte initiale
			VueInitiale.updateVueListe();
		}
	}

	/**
	 * Annule la création de la carte.
	 * Affiche une fenêtre de confirmation et ferme la fenêtre de création de carte.
	 */
	public void annuler() {
		// Afficher une fenêtre de dialogue
		int reponse = JOptionPane.showConfirmDialog(null,
				"Confirmez-vous l'annulation ?",
				"Confirmation", JOptionPane.YES_NO_OPTION);
		// Si le membre valide ses choix
		if (reponse == JOptionPane.YES_OPTION) {
			// Fermer la fenêtre
			frnListeCarte.dispose();
		}
	}

	/**
	 * Crée une nouvelle carte et l'affiche dans la liste.
	 * Affiche une fenêtre de confirmation, crée une carte vide, crée une instance
	 * de VueCarte avec la carte créée,
	 * crée une instance de VueModifierCarte, crée un écouteur et ajoute la vue de
	 * la carte à la fenêtre de la liste.
	 * Met à jour l'affichage de la fenêtre de la liste.
	 * L'utilisateur peut annulr la création de la carte.
	 * Et en modifiant la carte elle pourra être supprimer.
	 */
	public void cree() {
		// Afficher une fenêtre de dialogue
		int reponse = JOptionPane.showConfirmDialog(null,
				"Confirmez-vous la création de la carte ?",
				"Confirmation", JOptionPane.YES_NO_OPTION);
		// Si le membre valide ses choix
		if (reponse == JOptionPane.YES_OPTION) {

			// ---------------------------------
			// Créer une carte la carte
			ModeleCarte carte = VueCree.getCarteCree();

			Liste.sesCartes.add(carte);

			// Créer une instance de VueCarte avec la carte créée
			VueCarte vueCarte = new VueCarte(carte);

			// Créer une instance de VueModifierCarte
			VueModifierCarte vueModifierCarte = new VueModifierCarte(carte);
			// Création d'un écouteur
			ControleurCarte controleur = new ControleurCarte(carte, vueCarte, vueModifierCarte);

			// pour Carte
			// Lorsque l'on clique sur Modifier
			vueCarte.btnModifierClick(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controleur.modifierCarte();
				}
			});

			// Quand on clique sur Enregistrer
			vueModifierCarte.btnEnregistrerClick(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controleur.enregistrement();
				}
			});

			// Ajoute un écouteur au bouton "Supprimer" de la vue de la carte
			vueModifierCarte.btnSupprimerClick(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// Afficher une fenêtre de dialogue
					int reponse = JOptionPane.showConfirmDialog(null,
							"Confirmez-vous l'annulation ?",
							"Confirmation", JOptionPane.YES_NO_OPTION);
					// Si le membre valide ses choix
					if (reponse == JOptionPane.YES_OPTION) {
						// Supprime la carte de la liste
						Liste.getSesCartes().remove(carte);

						// Supprime la vue de la carte de la fenêtre de la liste
						VueInitiale.pnlPanneau.remove(vueCarte);

						// Actualise l'affichage de la fenêtre de la liste
						VueInitiale.revalidate();
						VueInitiale.repaint();

						// Fermer la fenêtre
						controleur.frnCarte.dispose();
					}
				}
			});

			// Ajouter la vue de la carte à la fenêtre de la liste
			VueInitiale.pnlPanneau.add(vueCarte);

			// Actualiser l'affichage de la fenêtre de la liste
			VueInitiale.revalidate();
			VueInitiale.repaint();

			// Fermer la fenêtre de création de carte
			frnListeCarte.dispose();

		}
	}

}
