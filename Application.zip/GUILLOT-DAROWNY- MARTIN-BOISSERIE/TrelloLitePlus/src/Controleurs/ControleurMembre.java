package Controleurs;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;
import java.util.*;
import Modeles.*;
import Vues.*;

/**
 * La classe ControleurMembre est une classe qui représente le contrôleur des membres.
 * Elle permet l'action des boutons grâce aux méthodes codées.
 * Ici, ControleurMembre permet de modifier le profil d'un membre, de rafraîchir le profil 
 * du membre, de voir les commentaires écrit par le membre, et les projets et cartes où participe le membre.
 * 
 * @author Estelle BOISSERIE
 **/

public class ControleurMembre {
	//---------------------------------
	// ATTRIBUTS
	//---------------------------------
	private ModeleMembre Membre;

	private VueMembre VueInitiale;
	private VueMembreModifie VueModifie;

	private JFrame fnrProfil = new JFrame("Modification Profil");

	private final static Color THEME = new Color(147, 112, 219);



	//---------------------------------
	// CONSTRUCTEUR
	//---------------------------------
	/**
	 * Constructeur de la classe ControleurMembre. 
	 * Il créé une instance de ControleurMembre afin de l'utiliser comme écouteur des vues.
	 * 
	 * @param membre Le membre
	 * @param vue Le profil du membre
	 * @param VueModifie La vue de modification du profil du membre
	 **/
	public ControleurMembre(ModeleMembre membre, VueMembre vue, VueMembreModifie VueModifie) {
		Membre = membre;
		VueInitiale = vue;
		this.VueModifie = VueModifie;

	}



	//---------------------------------
	// METHODES
	//---------------------------------
	/**
	 * Afficher la vue de modification du profil
	 **/
	public void modifierProfil() {
		// La fenêtre se ferme quand on appuit sur la croix
		fnrProfil.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		// Ajouter la vue
		fnrProfil.getContentPane().add(VueModifie);
		// Adapter de la taille de la fenêtre
		fnrProfil.pack();
		// Rendre visible la fenêtre
		fnrProfil.setVisible(true);
	}

	/**
	 * Enregistrer les nouvelles informations du membre
	 **/
	public void enregistrement() {
		// Enregistrer les nouvelles valeures
		Membre.setNomMembre(VueModifie.getNomMembre());
		Membre.setPrenomMembre(VueModifie.getPrenomMembre());
		Membre.setMailMembre(VueModifie.getMailMembre());
		
		// Vérifier les mots de passe
		// Si le mot de passe entré est différent du mot de passe en stockage
		if (!(VueModifie.getAncienMotdepasse().equals(Membre.getMotdepasseMembre()))) {
			// Afficher une erreure
			JOptionPane.showMessageDialog(null, "ERREUR: Le mot de passe actuel saisie est incorrect.", "Avertissement",
					JOptionPane.WARNING_MESSAGE);
		}
		// Si le nouveau mot de passe est différent du mot de passe en confirmation
		else if (!(VueModifie.getNouveauMotdepasse().equals(VueModifie.getMotdepasseConfirme()))) {
			// Afficher une erreure
			JOptionPane.showMessageDialog(null,
					"ERREUR: Le nouveau mot de passe n'est pas saisie correctement lors de sa confirmation.", "Avertissement",
					JOptionPane.WARNING_MESSAGE);
		}
		// Si non
		else {
			// Modifier le mot de passe
			Membre.setMotdepasseMembre(VueModifie.getNouveauMotdepasse());
		}
		// Afficher une fenêtre de dialogue
		int reponse = JOptionPane.showConfirmDialog(null,
				"Confirmez vous vos modifications ? Si vous laissez des erreurs, les modifications ne seront pas effectuées.",
				"Confirmation", JOptionPane.YES_NO_OPTION);
		// Si le membre valide ses choix
		if (reponse == JOptionPane.YES_OPTION) {
			// Fermer la fenêtre
			fnrProfil.dispose();
			// Vider les cases de saisie texte
			VueModifie.viderCase();
		}
	}

	/**
	 * Mettre a jour le profil
	 **/
	public void rafraichir() {
		VueInitiale.Redessiner(Membre);
	}

	/**
	 * Voir les commentaires écrit par le membre
	 **/
	public void voirCommentaire() {
		// Créer une fenêtre 
		JFrame fnrCommentaire = new JFrame("Mes commentaires :");
		
		// Créer un panel
		JPanel pnlCommentaire = new JPanel (new FlowLayout());
		
		// Si aucun commentaire
		if (Membre.getMesCommentaires().size()>=1) {
			// Pour chaque carte commentée par le membre
			for (int i = 0; i < Membre.getMesCommentaires().size(); i++) {
				// Créer la vue de la carte
				VueCommentaire commentaire = new VueCommentaire(Membre.getMesCommentaires().get(i));
				// Appliquer une bordure
				commentaire.setBorder(BorderFactory.createLineBorder(THEME));
				// Ajouter au pannel 
				pnlCommentaire.add(commentaire);
				// La fenêtre se ferme quand on appuit sur la croix
				fnrCommentaire.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				// Ajouter la vue à la fenêtre
				fnrCommentaire.getContentPane().add(pnlCommentaire);
				// Adapter de la taille de la fenêtre
				fnrCommentaire.pack();
				// Centrer la fenêtre
				fnrCommentaire.setLocationRelativeTo(null);
				// Rendre visible la fenêtre
				fnrCommentaire.setVisible(true);
			}
		}
		// Si non
		else {
			// Afficher une erreure
			JOptionPane.showMessageDialog(null,
					"ERREUR: Vous n'avez aucun commentaire.", "Avertissement",
					JOptionPane.WARNING_MESSAGE);
		}
	}

	/**
	 * Voir les projets dont le membre participe
	 **/
	public void voirProjet() {
		// Si le membre participe à des projets
		if (Membre.getMesProjets().size() >=1) {
			// Créer une fenêtre
			JFrame fnrProjet = new JFrame("Mes projets");
			// Créer un les labels
			JLabel lblProjet = new JLabel("Mes projets :");
			JLabel lblDescription = new JLabel("Description :");
			JLabel lblDate = new JLabel("Date échéance :");
			JLabel lblDescriptionProjet = new JLabel();
			JLabel lblDateProjet = new JLabel();
			// Créer les panels
			JPanel pnlProjet = new JPanel(new GridLayout(1,2));
			JPanel pnlDescription = new JPanel (new GridLayout(2,1));
			JPanel pnlDate = new JPanel (new GridLayout(2,1));
			JPanel pnlInfo = new JPanel (new GridLayout(1,2));
			JPanel pnlGeneral = new JPanel(new GridLayout(2,1));
			// Créer les listes
			DefaultListModel<String> TitreProjet = new DefaultListModel<>();
			ArrayList<ModeleProjet> Projet = new ArrayList<>();
			// Pour chaque projet dont le membre participe
			for (int i = 0; i < Membre.getMesProjets().size(); i++) {
				// Recupérer un projet
				ModeleProjet projet = (Membre.getMesProjets().get(i));
				// Ajouter le projet à une liste
				Projet.add(projet);
				// Ajouter le titre du projet à une liste liste
				TitreProjet.addElement(projet.getNomProjet());
			}
			// Ajouter les titres de projet à la liste
			JList<String> lstProjet = new JList<String>(TitreProjet);
			// Appliquer les styles de police
			lblProjet.setFont(new Font("Arial", Font.BOLD, 30));
			lstProjet.setFont(new Font("Arial", Font.BOLD, 20));
			pnlInfo.setFont(new Font("Arial", Font.BOLD, 10));
			// Appliquer une bordure
			pnlInfo.setBorder(BorderFactory.createLineBorder(THEME));
			// Appliquer des marges 
			pnlDescription.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 20));
			pnlDate.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 20));
			// Ajouter un écouteur à la liste
			lstProjet.addListSelectionListener(new ListSelectionListener() {
				/**
				 * La valeur de l'élément seléctionné a changé.
				 * @param e Evènement
				 **/
				public void valueChanged(ListSelectionEvent e) {
					// Si élément séléctionné
					if (!e.getValueIsAdjusting()) {
						// Obtenir l'élément sélectionné
						String ProjetSelectionne = lstProjet.getSelectedValue();
						// Obtenir l'indice de l'élément sélectionné
						int indice = lstProjet.getSelectedIndex();
						// Si l'élément n'est pas vide
						if (ProjetSelectionne != null) {
							// Sélectionner le projet concerné
							ModeleProjet selectedProjet = Projet.get(indice);
							// Afficher sa description et sa date d'échéance
							lblDescriptionProjet.setText(selectedProjet.getDescriptionProjet());
							lblDateProjet.setText(selectedProjet.getDateEcheanceProjet());
						} 
					}
				}
			});
			// Ajouter aux panels
			pnlDescription.add(lblDescription);
			pnlDescription.add(lblDescriptionProjet);
			pnlDate.add(lblDate);
			pnlDate.add(lblDateProjet);
			pnlInfo.add(pnlDescription);
			pnlInfo.add(pnlDate);
			pnlProjet.add(lstProjet);
			pnlProjet.add(pnlInfo);
			pnlGeneral.add(lblProjet, BorderLayout.WEST);
			pnlGeneral.add(pnlProjet, BorderLayout.EAST);
			// La fenêtre se ferme quand on appuit sur la croix
			fnrProjet.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			// Ajouter la vue à la fenêtre
			fnrProjet.getContentPane().add(pnlGeneral);
			// Adapter de la taille de la fenêtre
			fnrProjet.pack();
			// Centrer la fenêtre
			fnrProjet.setLocationRelativeTo(null);
			// Rendre visible la fenêtre
			fnrProjet.setVisible(true);
		}
		// Si non 
		else {
			// Afficher une erreure
			JOptionPane.showMessageDialog(null,
					"ERREUR: Vous n'avez aucun projet.", "Avertissement",
					JOptionPane.WARNING_MESSAGE);
		}
	}

	/**
	 * Voir les cartes dont le membre participe
	 **/
	public void voirCarte() {
		// Créer une fenêtre
		JFrame fnrCarte = new JFrame("Mes cartes :");
		// Créer un panel
		JPanel pnlCarte = new JPanel (new FlowLayout());
		// Si aucun commentaire
		if (Membre.getMesCartes().size()>=1) {
			// Pour chaque carte commentée par le membre
			for (int i = 0; i < Membre.getMesCartes().size(); i++) {
				// Créer la vue de la carte
				VueCarte carte = new VueCarte(Membre.getMesCartes().get(i));
				// Appliquer une bordure
				carte.setBorder(BorderFactory.createLineBorder(THEME));
				// Ajouter au pannel 
				pnlCarte.add(carte);
				// La fenêtre se ferme quand on appuit sur la croix
				fnrCarte.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				// Ajouter la vue à la fenêtre
				fnrCarte.getContentPane().add(pnlCarte);
				// Adapter de la taille de la fenêtre
				fnrCarte.pack();
				// Centrer la fenêtre
				fnrCarte.setLocationRelativeTo(null);
				// Rendre visible la fenêtre
				fnrCarte.setVisible(true);
			}
		}
		// Si non
		else {
			// Afficher une erreure
			JOptionPane.showMessageDialog(null,
					"ERREUR: Vous n'avez aucune carte.", "Avertissement",
					JOptionPane.WARNING_MESSAGE);
		}
	}

	/**
	 * Changer la photo de profil du membre
	 **/
	public void changerPhoto() {
		//Ouvrir l'explorateur de fichier
		JFileChooser ExplorateurDeFichier = new JFileChooser();
		// Afficher uniquement les fichiers d'images
		ExplorateurDeFichier.setFileFilter(new javax.swing.filechooser.FileFilter() {
			public boolean accept(File fichiers) {
				return fichiers.isDirectory() || fichiers.getName().toLowerCase().endsWith(".jpg")
						|| fichiers.getName().toLowerCase().endsWith(".png")
						|| fichiers.getName().toLowerCase().endsWith(".gif");
			}
			public String getDescription() {
				return "Fichiers d'images (*.jpg, *.png, *.gif)";
			}
		});
		// Afficher le sélecteur de fichiers
		int Resultat = ExplorateurDeFichier.showOpenDialog(VueModifie);
		// Si le fichier est sélectionné
		if (Resultat == JFileChooser.APPROVE_OPTION) {
			// Récupérer le fichier
			File FichierSelectionne = ExplorateurDeFichier.getSelectedFile();
			// Convertir le fichier en image
			ImageIcon PhotoSelectionnee = new ImageIcon(FichierSelectionne.getAbsolutePath());
			// Redimensionner l'image 
			Image Photo = PhotoSelectionnee.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
			ImageIcon NouvellePhotoDeProfil = new ImageIcon(Photo);
			// Créer un label pour la photo
			JLabel lblApercu = new JLabel();
			// Ajouter la photo au label
			lblApercu.setIcon(NouvellePhotoDeProfil);
			// Enregistrer la nouvelle image
			Membre.setImgProfil(NouvellePhotoDeProfil);
			// Afficher un aperçu de l'image sélectionnée
			JOptionPane.showMessageDialog(null, lblApercu, "Image sélectionnée", JOptionPane.PLAIN_MESSAGE);
		}
	}
}
