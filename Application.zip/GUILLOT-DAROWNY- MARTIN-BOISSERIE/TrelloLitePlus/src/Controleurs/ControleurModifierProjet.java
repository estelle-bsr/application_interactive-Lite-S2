package Controleurs;

import java.awt.event.*;

import javax.swing.*;

import Modeles.ModeleProjet;
import Vues.*;

/**
 * Cette classe est la classe controleur de ControleurModifierProjet. 
 * Elle permet de réaliser les évènements de le vue graphique de modifiaction d'un projet.
 * 
 * @author Antonin Guillot
 */
public class ControleurModifierProjet implements ActionListener{
	/******************
	 ** ATTRIBUTS **
	 ******************/
	private ModeleProjet Projet;
	private VueModifierProjet VueModif = new VueModifierProjet();
	private VueProjet VueInitiale;

	/******************
	 ** CONSTRUCTEUR **
	 ******************/
	public ControleurModifierProjet (ModeleProjet Projet, VueProjet VueInitiale) {
		this.Projet = Projet;
		this.VueInitiale = VueInitiale;

	}


	/******************
	 ** METHODES **
	 ******************/
	/**
	 * Reprend les données du projet et les affiche pour permettre de les modifier
	 * @param un click
	 */
	public void actionPerformed(ActionEvent e) {
		JFrame fnrModif = new JFrame ("Modification d'un projet");
		ControleurModifierProjet ecouteur = new ControleurModifierProjet(Projet, VueInitiale);
		VueModif.getTxtTitre().setText(Projet.getNomProjet());
		VueModif.getTxtDateEcheance().setText(Projet.getDateEcheanceProjet());
		VueModif.getTxtDescription().setText(Projet.getDescriptionProjet());
		fnrModif.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		fnrModif.add(VueModif);
		// Adapter la taille de la fenêtre
		fnrModif.pack();
		// Afficher la fenetre
		fnrModif.setVisible(true);

		/**
		 * Ferme la fenêtre de modification
		 * @param un click
		 */

		VueModif.btnAnnulerClick(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fnrModif.setVisible(false);
			}
		});

		/**
		 * Enregistre les modifications du projet et rafraichit la toute première vue
		 * @param un click
		 */

		VueModif.btnEnregistrerClick(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Projet.setNomProjet(VueModif.getTitre());
				Projet.setDescriptionProjet(VueModif.getDescription());
				Projet.setDateEcheanceProjet(VueModif.getDateEcheance());
				VueInitiale.Redessiner();
				fnrModif.dispose();

			}
		});
	}

}
