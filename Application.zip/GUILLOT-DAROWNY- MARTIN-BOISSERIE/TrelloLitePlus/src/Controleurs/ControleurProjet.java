package Controleurs;
import Modeles.*;

import Vues.*;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * Cette classe est la classe controleur de ControleurProjet. 
 * Elle permet de réaliser les évènements de le vue graphique des projets.
 * @author Antonin Guillot
 *
 */
public class ControleurProjet {
	/******************
	 ** ATTRIBUTS **
	 ******************/
	private ModeleMembre createur;
	private VueCreerProjet VueModif;
	private VueProjet VueInitiale;
	private final static Font POLICECORPS = new Font("New Times Romans", Font.PLAIN, 15);
	private final static Color COULEURBOUTON = new Color(147, 112, 219);
	private JFrame fnrCreation = new JFrame ("Création d'un projet");

	/******************
	 ** CONSTRUCTEUR **
	 ******************/
	/**
	 * Ce constructeur permet de créer une instance de la classe ControleurProjet
	 * @param Createur Le membre qui a créer le projet
	 * @param vueProjet La vue du projet quand on le créer
	 * @param VueInitiale La vue graphique du projet
	 */
	public ControleurProjet (ModeleMembre Createur, VueCreerProjet vueProjet, VueProjet VueInitiale) {
		createur = Createur;
		this.VueInitiale = VueInitiale;
		VueModif = vueProjet;
	}

	/******************
	 ** METHODES **
	 ******************/

	/**
	 * Permet d'afficher la vue pour créer un projet
	 */
	public void creerProjet () {
		fnrCreation.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		/*public void setSupprimerListener(ActionListener listener) {
			btnSupprimer.addActionListener(listener);
		}*/
		fnrCreation.add(VueModif);
		// Adapter la taille de la fenêtre
		fnrCreation.pack();
		// Afficher la fenetre
		fnrCreation.setVisible(true);

	}
	/**
	 * Permet de fermer la fenêtre de création et de réinitialiser les textes
	 */
	public void annulerProjet () {
		VueModif.getTxtTitre().setText("");
		VueModif.getTxtDateEcheance().setText("");
		VueModif.getTxtDescription().setText("");
		fnrCreation.dispose();
	}

	/**
	 * Permet d'enregistrer un projet et d'afficher le titre avec deux boutons (Modifier, Supprimer et Ouvrir le projet)
	 * @author Antonin Guillot
	 * @author Estelle BOISSERIE
	 */
	public void enregistrerProjet() {
		ModeleProjet Projet = new ModeleProjet (VueModif.getTitre(), createur,  VueModif.getDescription(), VueModif.getDateEcheance());
		ModelePrend_par participation = new ModelePrend_par(Projet, createur, true);
		JLabel titre = new JLabel(VueModif.getTitre());
		JButton btnModif = new JButton ("Modifier");
		JButton btnSuppr = new JButton ("Supprimer");
		JButton btnVoir = new JButton ("Ouvrir Projet");
		JPanel pnlProjet = new JPanel ();

		btnSuppr.addActionListener(new ControleurSupprimerProjet(pnlProjet));
		btnModif.addActionListener(new ControleurModifierProjet(Projet, VueInitiale));
		btnVoir.addActionListener(new ControleurVoirProjet(Projet, VueInitiale));

		pnlProjet.add(titre);
		pnlProjet.add(btnModif);
		pnlProjet.add(btnSuppr);
		pnlProjet.add(btnVoir);

		titre.setFont(POLICECORPS);
		btnModif.setBackground(COULEURBOUTON);
		btnSuppr.setBackground(COULEURBOUTON);
		btnVoir.setBackground(COULEURBOUTON);

		VueInitiale.getPnlGlobal().add(pnlProjet);
		VueModif.getTxtTitre().setText("");
		VueModif.getTxtDateEcheance().setText("");
		VueModif.getTxtDescription().setText("");
		fnrCreation.dispose();
		fnrCreation.pack();

	}





}
