
package Controleurs;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import Modeles.*;
import Vues.*;

/**
 * Cette classe est la classe controleur de ControleurTableau. 
 * Elle permet de réaliser les évènements de le vue graphique des tableaux.
 * @author Cathy MARTIN
 *
 */
public class ControleurTableau {
	/******************
	 ** ATTRIBUTS **
	 ******************/
	private ModeleTableau Tableau;
	private VueTableau VueInitiale;
	private VueModifierTableau VueModifie;
	private VueCreeListe VueCree;
	private JFrame frnTableau = new JFrame("Modifier tableau");
	private JFrame frnTableauListe = new JFrame("Création liste");

	/**********************
	 ** CONSTRUCTEUR **
	 **********************/
	/**
	 * Ce constructeur permet de créer une instance de la classe ControleurTableau
	 * @param membre Le tableau
	 * @param vue La vue graphique du tableau
	 * @param VueModifie La vue graphique de la modification du tableau
	 * @param VueCree La vue graphique de la création d'une liste
	 */
	public ControleurTableau(ModeleTableau membre, VueTableau vue, VueModifierTableau VueModifie, VueCreeListe VueCree) {
		Tableau = membre;
		VueInitiale = vue;
		this.VueModifie = VueModifie;
		this.VueCree = VueCree;

		// Ajouter l'écouteur pour le bouton "Créer" de la vue de création de la liste
		VueCree.btnCreeClick(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreeListe();
			}
		});
	}

	/******************
	 ** METHODES **
	 ******************/

	// Afficher la vue permettant de cree une liste
	public ModeleListe CreeListe() {
		// créé une liste vide
		ModeleListe liste = new ModeleListe("");

		// Configurer la fenêtre
		frnTableauListe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		// Ajouter la vue
		frnTableauListe.getContentPane().add(VueCree);
		// Adapter de la taille de la fenêtre
		frnTableauListe.pack();
		// Rendre visible la fenêtre
		frnTableauListe.setVisible(true);
		return liste;
	}

	// Afficher la vue permettant de modifier le titre du tableau
	public void modifierTableau() {
		// Configurer la fenêtre
		frnTableau.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		// Ajouter la vue
		frnTableau.getContentPane().add(VueModifie);
		// Adapter de la taille de la fenêtre
		frnTableau.pack();
		// Rendre visible la fenêtre
		frnTableau.setVisible(true);
	}

	// Enregistrer les choix effectués
	public void enregistrement() {
		// Enregistrer du nouveau nom
		Tableau.setNomTableau(VueModifie.getTitre());

		// Afficher une fenêtre de dialogue
		int reponse = JOptionPane.showConfirmDialog(null,
				"Confirmez-vous vos modifications ?",
				"Confirmation", JOptionPane.YES_NO_OPTION);
		// Si le membre valide ses choix
		if (reponse == JOptionPane.YES_OPTION) {
			// Fermer la fenêtre
			frnTableau.dispose();
			// Mettre à jour la vue du tableau initiale
			VueInitiale.updateVueTableau();
		}
	}

	// Annuler la création de la liste
	public void annuler() {

		// Afficher une fenêtre de dialogue
		int reponse = JOptionPane.showConfirmDialog(null,
				"Confirmez-vous l'annulation ?",
				"Confirmation", JOptionPane.YES_NO_OPTION);
		// Si le membre valide ses choix
		if (reponse == JOptionPane.YES_OPTION) {
			// Fermer la fenêtre
			frnTableauListe.dispose();
		}
	}

	// créé une nouvelle liste et l'afficher au tableau
	public void cree() {

		// Afficher une fenêtre de dialogue
		int reponse = JOptionPane.showConfirmDialog(null,
				"Confirmez-vous la création de la liste ?",
				"Confirmation", JOptionPane.YES_NO_OPTION);

		// Si le membre valide ses choix
		if (reponse == JOptionPane.YES_OPTION) {

			// Créer une liste vide
			ModeleListe liste = new ModeleListe("");
			liste = VueCree.getListeCree();

			Tableau.sesListes.add(liste);

			// Créer une instance de VueListe avec la liste créée
			VueListe vueListe = new VueListe(liste);
			// Pour l'ajout de carte
			ModeleCarte carteNull = new ModeleCarte("", "", "00/00/0000");
			VueCreeCarte VueCreeCarte = new VueCreeCarte(carteNull);

			// Créer une instance de VueModifierListe
			VueModifierListe vueModifierListe = new VueModifierListe(liste);
			// Création d'un écouteur
			ControleurListe controleurListe = new ControleurListe(liste, vueListe, vueModifierListe, VueCreeCarte);

			// Pour liste
			// Lorsque l'on clique sur Modifier
			vueListe.btnModifierClick(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controleurListe.modifierListe();
				}
			});

			// Lorsque l'on clique sur Ajouter une carte
			vueListe.btnAjouterCarteClick(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controleurListe.CreeCarte();
				}
			});

			// Quand on clique sur Enregistrer
			vueModifierListe.btnEnregistrerClick(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controleurListe.enregistrement();
				}
			});

			// Quand on clique sur Créé
			VueCreeCarte.btnCreeClick(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controleurListe.cree();
				}
			});

			// Quand on clique sur Créé
			VueCreeCarte.btnAnnulerClick(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controleurListe.annuler();
				}
			});

			// Ajouter la vue de la carte à la fenêtre de la liste
			VueInitiale.pnlPanneauTableau.add(vueListe);

			// Actualiser l'affichage de la fenêtre de la liste
			VueInitiale.revalidate();
			VueInitiale.repaint();

			// Fermer la fenêtre de création de carte
			frnTableauListe.dispose();

		}
	}

}
