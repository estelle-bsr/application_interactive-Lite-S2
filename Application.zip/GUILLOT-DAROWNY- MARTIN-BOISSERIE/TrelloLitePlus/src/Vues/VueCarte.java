package Vues;

import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.Border;
import Modeles.*;

/**
 * @author Cathy MARTIN
 *
 *         La classe VueCarte est une vue qui affiche les informations d'une
 *         carte.
 *         Elle permet également d'ajouter des écouteurs pour les actions de
 *         modification de la carte.
 * 
 *         Elle est utilisée pour afficher une carte dans la liste.
 * 
 */

public class VueCarte extends JPanel {
	/******************
	 ** ATTRIBUTS **
	 ******************/
	private ModeleCarte carte;
	private JLabel lblNomCarte;
	private JLabel lblDescriptionCarte;
	private JLabel lblDateCarte;
	private JLabel lblStatutCarte;
	private JButton btnModifier;

	/**********************
	 ** CONSTRUCTEUR **
	 **********************/

	/**
	 * Constructeur de la classe VueCarte.
	 * Crée une vue pour afficher les informations d'une carte.
	 * 
	 * @param carte la Carte à afficher
	 */
	public VueCarte(ModeleCarte Carte) {
		// Mémoriser le modèle sur lequel ce panel est une vue
		this.carte = Carte;

		setLayout(new GridBagLayout());

		// Créer le panneau pour le titre de la carte
		JPanel pnlTitre = new JPanel(new GridBagLayout());
		lblNomCarte = new JLabel(carte.getNomCarte().toUpperCase());
		lblNomCarte.setFont(new Font("Arial", Font.BOLD, 20)); // l'estetique du titre
		GridBagConstraints gbcTitre = new GridBagConstraints();
		gbcTitre.gridx = 0;
		gbcTitre.gridy = 0;
		gbcTitre.anchor = GridBagConstraints.CENTER;
		pnlTitre.add(lblNomCarte, gbcTitre);

		// Créer le panneau pour les informations de la carte
		JPanel pnlInfo = new JPanel(new GridBagLayout());
		lblDescriptionCarte = new JLabel(carte.getDescriptionCarte());
		lblDateCarte = new JLabel(carte.getDateEcheanceCarte());
		lblStatutCarte = new JLabel(carte.getStatutCarte());
		GridBagConstraints gbcInfo = new GridBagConstraints();

		gbcInfo.gridx = 0;
		gbcInfo.gridy = 0;
		gbcInfo.anchor = GridBagConstraints.LINE_START;
		pnlInfo.add(new JLabel("Description: "), gbcInfo);

		gbcInfo.gridx = 1;
		gbcInfo.gridy = 0;
		pnlInfo.add(lblDescriptionCarte, gbcInfo);

		gbcInfo.gridx = 0;
		gbcInfo.gridy = 1;
		pnlInfo.add(new JLabel("Date limite: "), gbcInfo);

		gbcInfo.gridx = 1;
		gbcInfo.gridy = 1;
		pnlInfo.add(lblDateCarte, gbcInfo);

		gbcInfo.gridx = 0;
		gbcInfo.gridy = 2;
		pnlInfo.add(new JLabel("Statut: "), gbcInfo);

		gbcInfo.gridx = 1;
		gbcInfo.gridy = 2;
		pnlInfo.add(lblStatutCarte, gbcInfo);

		// Créer le boutton de modification de la carte
		btnModifier = new JButton("Modifier");

		JPanel pnlPanneau = new JPanel(new GridBagLayout());

		// Ajouter les sous-panneaux au panneau principal
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.PAGE_START; // indique que le composant doit être ancré en haut de la cellule
		gbc.insets = new Insets(5, 5, 5, 5);
		pnlPanneau.add(pnlTitre, gbc);
		gbc.gridy = 1;
		gbc.anchor = GridBagConstraints.LINE_START; // indique que le composant doit être ancré à gauche de la cellule
		pnlPanneau.add(pnlInfo, gbc);

		gbc.gridy = 2;
		gbc.anchor = GridBagConstraints.CENTER;
		pnlPanneau.add(btnModifier, gbc);

		// créer une bordure de trait noir et largeur minimale 1
		Border lineborder = BorderFactory.createLineBorder(Color.black, 1);

		// associer à un JPanel
		pnlPanneau.setBorder(lineborder);
		add(pnlPanneau);
	}

	/******************
	 ** METHODES **
	 ******************/
	/**
	 * Ajoute un écouteur pour l'action de cliquer sur le bouton "Modifier".
	 * 
	 * @param ecouteur l'écouteur à ajouter
	 */
	public void btnModifierClick(ActionListener ecouteur) {
		btnModifier.addActionListener(ecouteur);
	}

	/**
	 * Met à jour l'affichage de la vue de la carte avec les informations de la
	 * carte actuelle.
	 */
	public void updateVueCarte() {
		lblNomCarte.setText(carte.getNomCarte().toUpperCase());
		lblDescriptionCarte.setText(carte.getDescriptionCarte());
		lblDateCarte.setText(carte.getDateEcheanceCarte());
		lblStatutCarte.setText(carte.getStatutCarte());
	}

}
