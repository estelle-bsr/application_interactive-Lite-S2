package Vues;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import Modeles.*;

/**
 * La classe VueCommentaire est la vue graphique des commentaires.
 * Elle permet à l'ulisateur de visualiser les fonctionnalités des commentaires.
 * 
 * @author Estelle BOISSERIE
 **/
public class VueCommentaire extends JPanel {
	//---------------------------------
	// ATTRIBUTS
	//---------------------------------
	private ModeleCommentaire modele;
	private JLabel lblTexte;
	private JLabel lblAuteur;
	private JLabel lblTexteTitre = new JLabel("Commentaire :");
	private JLabel lblAuteurTitre = new JLabel("Auteur :"    );
	private JButton btnProfil = new JButton ("Profil"        );
	private JButton btnCarte = new JButton("Carte"           );
	private JPanel pnlAuteur = new JPanel(new GridLayout(1,2)     );
	private JPanel pnlContenuCommentaire = new JPanel(            );
	private JPanel pnlCommentaire = new JPanel(new GridLayout(2,1));
	private JPanel pnlGeneral = new JPanel(new GridLayout(2,1)    );
	private JPanel pnlBoutons = new JPanel(new GridLayout (1,2)    );
	private Font typeEcritureTitre = new Font("Arial", Font.BOLD, 20      );
	private Font typeEcriture = new Font("New Times Romans", Font.PLAIN, 15);
	private Color couleurBoutons = new Color(147, 112, 219);


	//---------------------------------
	// CONSTRUCTEUR
	//---------------------------------
	/**
	 * Constructeur de la classe VueCommentaire.
	 * Ce constructeur permet de créer une instance de la calsse qui servira à représenter la vue d'un commentaire.
	 * 
	 * @param modele Le commentaire représenté dans la vue graphique
	 */
	public VueCommentaire(ModeleCommentaire modele) {
		// Mémoriser le modèle(commentaire) sur lequel ce panel est une vue
		this.modele = modele;

		// Définir le contenu des labels
		lblAuteur = new JLabel (modele.getNomAuteur() + " " + modele.getPrenomAuteur()); 
		lblTexte = new JLabel (modele.gettexteCommentaire());

		// Appliquer les styles de police
		lblAuteurTitre.setFont(typeEcritureTitre);
		lblAuteur.setFont(typeEcriture);
		lblTexteTitre.setFont(typeEcritureTitre);
		lblTexte.setFont(typeEcriture);

		//Mise en page du contenu du commentaire
		lblTexte.setBorder(BorderFactory.createLineBorder(couleurBoutons));
		pnlContenuCommentaire.setBackground(Color.WHITE);

		// Appliquer la couleur aux boutons
		btnProfil.setBackground(couleurBoutons);
		btnCarte.setBackground(couleurBoutons);
		// Appliquer le style de police aux boutons
		btnProfil.setFont(typeEcritureTitre);
		btnCarte.setFont(typeEcritureTitre);

		// Mise en page de la vue
		setLayout(new BorderLayout());

		// Ajouter les éléments aux panels
		pnlContenuCommentaire.add(lblTexte);
		pnlCommentaire.add(lblTexteTitre);
		pnlCommentaire.add(pnlContenuCommentaire);
		pnlAuteur.add(lblAuteurTitre);
		pnlAuteur.add(lblAuteur);
		pnlGeneral.add(pnlAuteur);
		pnlGeneral.add(pnlCommentaire);
		pnlBoutons.add(btnProfil);
		pnlBoutons.add(btnCarte);

		// Ajouter les panels à la vue
		add(pnlGeneral, BorderLayout.NORTH);
		add(pnlBoutons, BorderLayout.SOUTH);
	}



	//---------------------------------
	// METHODES
	//---------------------------------
	/**
	 * Ajouter un écouteur au bouton "Profil".
	 * @param ecouteur L'écouteur 
	 */
	public void btnProfilClick(ActionListener ecouteur) {
		btnProfil.addActionListener(ecouteur);
	}
}
