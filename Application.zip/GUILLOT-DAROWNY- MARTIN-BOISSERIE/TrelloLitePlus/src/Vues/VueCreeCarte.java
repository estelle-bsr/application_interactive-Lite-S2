package Vues;

import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;
import Modeles.*;

/**
 * @author Cathy MARTIN
 *
 *         La classe VueCreeCarte représente une vue pour créer une nouvelle
 *         carte.
 *         Elle affiche les champs de saisie tels que le titre, la description
 *         et la date limite de la carte.
 *         Les utilisateurs peuvent remplir ces champs et créer une nouvelle
 *         carte en cliquant sur le bouton "Créer".
 *         Ils ont également la possibilité d'annuler la création en cliquant
 *         sur le bouton "Annuler".
 * 
 */

public class VueCreeCarte extends JPanel {
	/******************
	 **   ATTRIBUTS  **
	 ******************/
	private ModeleCarte carte;
	private JTextField txtTitre;
	private JTextArea txtDescription; // pouvoir mettre du text sur plusieur ligne
	private JTextField txtDateLimite;
	private JButton btnCree;
	private JButton btnAnnuler;

	/**********************
	 **   CONSTRUCTEUR   **
	 **********************/

	/**
	 * Constructeur de la classe VueCreeCarte.
	 * Crée une vue pour pouvoir créer une carte.
	 * @param carte La carte à créer.
	 */
	public VueCreeCarte(ModeleCarte carte) {
		this.carte = carte;

		setLayout(new BorderLayout());

		JPanel pnlModif = new JPanel(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.LINE_START;
		gbc.insets = new Insets(5, 5, 5, 5); // espace entre le JPanel et la JText

		// Titre
		JLabel lblTitre = new JLabel("Titre:");
		pnlModif.add(lblTitre, gbc);

		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		txtTitre = new JTextField(15);
		pnlModif.add(txtTitre, gbc);

		// Description
		gbc.gridx = 0;
		gbc.gridy = 1;
		JLabel lblDescription = new JLabel("Description:");
		pnlModif.add(lblDescription, gbc);

		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		txtDescription = new JTextArea();
		txtDescription.setRows(3);
		JScrollPane scrollPane = new JScrollPane(txtDescription);
		pnlModif.add(scrollPane, gbc);

		// Date limite
		gbc.gridx = 0;
		gbc.gridy = 2;
		JLabel lblDateLimite = new JLabel("Date limite:");
		pnlModif.add(lblDateLimite, gbc);

		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		txtDateLimite = new JTextField(carte.getDateEcheanceCarte());
		pnlModif.add(txtDateLimite, gbc);

		// Bouton Créé
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.gridwidth = 2; // Le composant occupe deux cellules horizontalement
		btnCree = new JButton("Créé");
		pnlModif.add(btnCree, gbc);

		// Bouton Supprimer
		btnAnnuler = new JButton("Annuler");

		// Ajout des composants au panneau principal
		add(pnlModif, BorderLayout.CENTER);
		add(btnAnnuler, BorderLayout.SOUTH);
	}

	/******************
	 ** METHODES **
	 ******************/

	/**
	 * Ajoute un écouteur pour l'action de cliquer sur le bouton "Annuler".
	 * 
	 * @param ecouteur l'écouteur à ajouter
	 */
	public void btnAnnulerClick(ActionListener ecouteur) {
		btnAnnuler.addActionListener(ecouteur);
	}

	/**
	 * Ajoute un écouteur pour l'action de cliquer sur le bouton "Créé".
	 * 
	 * @param ecouteur l'écouteur à ajouter
	 */
	public void btnCreeClick(ActionListener ecouteur) {
		btnCree.addActionListener(ecouteur);
	}

	/**
	 * Récupère la carte créée avec les informations saisies dans les champs de texte.
	 * @return La carte créée.
	 */
	public ModeleCarte getCarteCree() {
		String titre = getTitre().getText();
		String description = getDescription().getText();
		String dateLimite = getDateLimite().getText();
		return new ModeleCarte(titre, description, dateLimite);
	}

	/******************
	 ** ACCESSEURS **
	 *******************/

	/**
	 * Récupère le titre saisi dans le champ de texte.
	 * @return Le JTextField du titre de la carte.
	 */
	public JTextField getTitre() {
		return txtTitre;
	}

	/**
	 * Récupère la description saisie dans le champ de texte.
	 * @return Le JTextArea de la description de la carte.
	 */
	public JTextArea getDescription() {
		return txtDescription;
	}

	/**
	 * Récupère la date limite saisie dans le champ de texte.
	 * @return Le JTextField de la date limite de la carte.
	 */
	public JTextField getDateLimite() {
		return txtDateLimite;
	}

}
