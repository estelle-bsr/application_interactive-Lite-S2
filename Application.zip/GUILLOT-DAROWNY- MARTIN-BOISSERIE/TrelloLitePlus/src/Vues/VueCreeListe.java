package Vues;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import Modeles.*;

/**
 * @author Cathy MARTIN
 *
 *         La classe VueCreeListe représente une vue pour créer une nouvelle
 *         liste.
 *         Elle affiche le champ de saisie pour le titre.
 *         Les utilisateurs peuvent remplir ce champ et créer une nouvelle liste
 *         en cliquant sur le bouton "Créer".
 *         Ils ont également la possibilité d'annuler la création en cliquant
 *         sur le bouton "Annuler".
 * 
 */

public class VueCreeListe extends JPanel {
	/******************
	 ** ATTRIBUTS **
	 ******************/
	private ModeleListe liste;
	private JTextField txtTitre;
	private JButton btnCree;
	private JButton btnAnnuler;

	/**********************
	 ** CONSTRUCTEUR **
	 **********************/

	/**
	 * Constructeur de la classe VueCreeListe.
	 * Crée une vue pour pouvoir créer une liste.
	 * 
	 * @param liste La liste à créer.
	 */
	public VueCreeListe(ModeleListe liste) {
		this.liste = liste;

		setLayout(new BorderLayout());

		JPanel pnlModif = new JPanel(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.LINE_START;
		gbc.insets = new Insets(5, 5, 5, 5); // espace (haut,gauche,bat,droit)

		// Titre
		JLabel lblTitre = new JLabel("Titre:");
		pnlModif.add(lblTitre, gbc);
		// Place pour ecrire
		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		txtTitre = new JTextField(10);
		pnlModif.add(txtTitre, gbc);

		// Bouton Créé
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 2; // Le composant occupe deux cellules horizontalement
		btnCree = new JButton("Créé");
		pnlModif.add(btnCree, gbc);

		// Bouton Annuler
		btnAnnuler = new JButton("Annuler");

		// Ajout des composants au panneau principal
		add(pnlModif, BorderLayout.CENTER);
		add(btnAnnuler, BorderLayout.SOUTH);
	}

	/******************
	 ** METHODES **
	 ******************/
	/**
	 * Ajoute un écouteur pour l'action de cliquer sur le bouton "Annuler".
	 * 
	 * @param ecouteur l'écouteur à ajouter
	 */
	public void btnAnnulerClick(ActionListener ecouteur) {
		btnAnnuler.addActionListener(ecouteur);
	}

	/**
	 * Ajoute un écouteur pour l'action de cliquer sur le bouton "Créé".
	 * 
	 * @param ecouteur l'écouteur à ajouter
	 */
	public void btnCreeClick(ActionListener ecouteur) {
		btnCree.addActionListener(ecouteur);
	}

	/**
	 * Récupère la liste créée avec l'information saisie dans le champ de texte.
	 * 
	 * @return La liste créée.
	 */
	public ModeleListe getListeCree() {
		String titre = getTxtTitre().getText();
		return new ModeleListe(titre);
	}

	/******************
	 ** ACCESSEURS **
	 *******************/
	/**
	 * Récupère le titre saisi dans le champ de texte.
	 * 
	 * @return Le JTextField du titre de la liste.
	 */
	public JTextField getTxtTitre() {
		return txtTitre;
	}

}
