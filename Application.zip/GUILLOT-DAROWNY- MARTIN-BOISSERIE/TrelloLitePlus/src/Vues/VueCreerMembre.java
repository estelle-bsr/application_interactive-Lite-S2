package Vues;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


/**
 * Cette classe est la classe VueCreerMembre
 * Elle représente la vue graphique de la création d'un compte
 * Elle affichée lorsque le membre souhaite créer un compte lors du lancement de l'application
 * 
 * @author Estelle BOISSERIE
 **/
public class VueCreerMembre extends JPanel {
	//---------------------------------
	// ATTRIBUTS
	//---------------------------------
	private JLabel lblTitre = new JLabel ("Créer votre compte"                                );
	private JLabel lblNom = new JLabel("Nom : "                                               );
	private JLabel lblPrenom = new JLabel("Prénom : "                                         );
	private JLabel lblMail = new JLabel("Adresse mail : "                                     );
	private JLabel lblMotdepasse = new JLabel("Votre mot de passe : "                         );
	private JLabel lblMotdepasseConfirme = new JLabel("Confimer votre  mot de passe : "       );

	private JTextField txtNom = new JTextField(10   );
	private JTextField txtPrenom = new JTextField(10);
	private JTextField txtMail = new JTextField(10  );

	private JPasswordField txtMotdepasse = new JPasswordField(10         );
	private JPasswordField txtMotdepasseConfirme = new JPasswordField(10);

	private JButton btnCreer = new JButton("Créer"  );
	private JButton btnRetour = new JButton("Retour");

	private JPanel pnlNom = new JPanel(new GridLayout(1,2)         );
	private JPanel pnlPrenom = new JPanel(new GridLayout(1,2)      );
	private JPanel pnlMail = new JPanel(new GridLayout(1,2)        );
	private JPanel pnlMotdepasse = new JPanel(new GridLayout(1,2)  );
	private JPanel pnlConfirmation = new JPanel(new GridLayout(1,2));
	private JPanel pnlBoutons = new JPanel(new BorderLayout()      );
	private JPanel pnlNomPrenom = new JPanel(new BorderLayout()    );

	private final static Font POLICETITRE = new Font("Arial", Font.BOLD, 20            );
	private final static Font POLICECORPS = new Font("New Times Romans", Font.PLAIN, 15);
	private final static Font POLICESAISIE = new Font("Console", Font.PLAIN, 15        );

	private final static Color COULEURBOUTON = new Color(147, 112, 219);




	//---------------------------------
	// CONSTRUCTEUR
	//---------------------------------
	/**
	 * Constructeur de la classe VueCreerMembre.
	 * Ce constructeur permet de créer une instance de VueCreerMembre qui représente la vue de création d'un compte.
	 **/
	public VueCreerMembre() {
		// Appliquer la police d'écriture
		lblTitre.setFont(POLICETITRE);
		btnCreer.setFont(POLICETITRE);
		btnRetour.setFont(POLICETITRE);
		lblNom.setFont(POLICECORPS);
		lblPrenom.setFont(POLICECORPS);
		lblMail.setFont(POLICECORPS);
		lblMotdepasse.setFont(POLICECORPS);
		lblMotdepasseConfirme.setFont(POLICECORPS);
		txtNom.setFont(POLICESAISIE);
		txtPrenom.setFont(POLICESAISIE);
		txtMail.setFont(POLICESAISIE);
		txtMotdepasse.setFont(POLICESAISIE);
		txtMotdepasseConfirme.setFont(POLICESAISIE);
		
		// Appliquer la couleur
		btnCreer.setBackground(COULEURBOUTON);
		btnRetour.setBackground(COULEURBOUTON);
		setBackground(COULEURBOUTON);
		
		// Appliquer des marges
		setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

		
		// Ajouter aux panels
		pnlNom.add(lblNom);
		pnlNom.add(txtNom);
		pnlPrenom.add(lblPrenom);
		pnlPrenom.add(txtPrenom);
		pnlMail.add(lblMail);
		pnlMail.add(txtMail);
		pnlMotdepasse.add(lblMotdepasse);
		pnlMotdepasse.add(txtMotdepasse);
		pnlConfirmation.add(lblMotdepasseConfirme);
		pnlConfirmation.add(txtMotdepasseConfirme);
		pnlBoutons.add(btnRetour, BorderLayout.EAST);
		pnlBoutons.add(btnCreer, BorderLayout.WEST);
		pnlNomPrenom.add(pnlNom, BorderLayout.EAST);
		pnlNomPrenom.add(pnlPrenom, BorderLayout.WEST);

		// Mettre en page la vue
		setLayout(new GridLayout(5,1));

		// Ajouter à la vue
		add(pnlNomPrenom);
		add(pnlMail);
		add(pnlMotdepasse);
		add(pnlConfirmation);
		add(pnlBoutons);
	}



	//---------------------------------
	// METHODES
	//---------------------------------
	/**
	 * Ajouter un écouteur au bouton "Créer".
	 * @param ecouteur L'écouteur
	 **/
	public void btnCreerClick(ActionListener ecouteur) {
		btnCreer.addActionListener(ecouteur);
	}

	/**
	 * Ajouter un écouteur au bouton "Retour".
	 * @param ecouteur L'écouteur
	 **/
	public void btnRetourClick(ActionListener ecouteur) {
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Appel à l'écouteur d'événements
				if (ecouteur != null) {
					ecouteur.actionPerformed(e);
				}

				// Fermeture de la fenêtre
				Window window = SwingUtilities.getWindowAncestor(VueCreerMembre.this);
				window.dispose();
			}
		});
	}



	//---------------------------------
	// ACCESSEURS
	//---------------------------------
	/**
	 * Avoir le nom saisie par l'utlisateur.
	 * @return Le nom saisie
	 **/
	public String getNom() {
		return txtNom.getText();
	}
	/**
	 * Avoir le prénom saisie par l'utlisateur.
	 * @return Le prénom saisie
	 **/
	public String getPrenom() {
		return txtPrenom.getText();
	}
	/**
	 * Avoir l'adresse mail saisie par l'utlisateur.
	 * @return L'adresse mail saisie
	 **/
	public String getMail() {
		return txtMail.getText();
	}
	/**
	 * Avoir le mot de passe saisie par l'utlisateur.
	 * @return Le mot de passe saisie
	 **/
	public String getMotdepasse() {
		char[] motdepasse = txtMotdepasse.getPassword();
		return new String(motdepasse);
	}
	/**
	 * Avoir le mot de passe de confirmation saisie par l'utlisateur.
	 * @return Le mot de passe de confirmation saisie
	 **/
	public String getTxtMotdepasseConfirme() {
		char[] motdepasse = txtMotdepasseConfirme.getPassword();
		return new String(motdepasse);
	}
	/**
	 * Modifier le contenu de la case de saisie de nom
	 * @param nom Le nouveau contenu
	 **/
	public void setNom(String nom) {
		txtNom.setText(nom);;
	}
	/**
	 * Modifier le contenu de la case de saisie de prénom
	 * @param prenom Le nouveau contenu
	 **/
	public void setPrenom(String prenom) {
		txtPrenom.setText(prenom);
	}
	/**
	 * Modifier le contenu de la case de saisie de mail
	 * @param nom Le nouveau contenu
	 **/
	public void setMail(String mail) {
		txtMail.setText(mail);;
	}
	/**
	 * Modifier le contenu de la case de saisie de mot de passe
	 * @param nom Le nouveau contenu
	 **/
	public void setMotdepasse(String motdepasse) {
		txtMotdepasse.setText(motdepasse);
	}
	/**
	 * Modifier le contenu de la case de saisie de mot de passe de confirmation
	 * @param nom Le nouveau contenu
	 **/
	public void setMotdepasseConfirme(String motdepasse) {
		txtMotdepasseConfirme.setText(motdepasse);
	}
}
