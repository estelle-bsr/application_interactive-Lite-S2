package Vues;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import Modeles.*;
import Controleurs.*;

/**
 * La classe VueGlobale est la représentation graphique de la gestion du projet. 
 * A partir de cette vue l'utilisateur peut avoir accès à son profil, aux participants du projet, 
 * gérer les participants, visualiser et gérer les tableaux du projet ainsi que les listes et les cartes. 
 * 
 * @author Estelle BOISSERIE
 **/

public class VueGlobale extends JPanel{
	//---------------------------------
	// ATTRIBUTS
	//---------------------------------
	private ModeleProjet modele;

	private DefaultListModel<String> TitreTableau = new DefaultListModel<>();
	private ArrayList<ModeleTableau> Tableau = new ArrayList<>()            ;

	private JList<String> lstTableau;

	private JLabel lblLogo = new JLabel("Lite +");
	private JLabel lblTitreProjet                ;
	private JLabel lblPhotoMembre                ;

	private JButton btnMembre                                                      ;
	private JButton btnAjouterParticipant = new JButton("Ajouter des participants");
	private JButton btnRafraichir = new JButton("Rafraîchir"                      );
	private JButton btnAjouterTableau = new JButton("+"                           );
	private JButton btnVoirParticipant = new JButton("Voir les participants"      );

	private JPanel pnlMembre = new JPanel(new GridLayout(1,2)        );
	private JPanel pnlInformation= new JPanel (new GridLayout(1,3)   );
	private JPanel pnlListeTableau = new JPanel(new GridLayout(2,1)  );
	private JPanel pnlBoutons = new JPanel (new BorderLayout()       );
	private JPanel pnlBoutonPlus = new JPanel(new GridLayout(1,2)    );
	private JPanel pnlBandeauBoutons = new JPanel(new GridLayout(2,1));
	private JPanel pnlVueTableau = new JPanel(new FlowLayout()       );
	private JPanel pnlGeneral = new JPanel (new GridLayout(1,2)      );

	private final static Border BORDURE = BorderFactory.createLineBorder(Color.BLACK, 2);

	private final static Font POLICETITRE = new Font("Arial", Font.BOLD, 20            );
	private final static Font POLICECORPS = new Font("New Times Romans", Font.PLAIN, 15);

	private final static Color COULEURTHEME = new Color(147, 112, 219);



	//---------------------------------
	// CONSTRUCTEUR
	//---------------------------------
	/**
	 * Constructeur de la classe VueGlobale.
	 * Il créer une instance de VueGlobale afin de visualiser l'ensemble du projet.
	 * 
	 * @param modele Le projet affiché
	 **/
	public VueGlobale(ModeleProjet modele) {
		// Mémoriser le modele(projet) sur lequel ce panel est une vue
		this.modele = modele;

		// Pour chaque tableau du projet
		for (int i = 0; i < modele.getTableaux().size(); i++) {
			// Récupérer un tableau
			ModeleTableau tableau = (modele.getTableaux().get(i));
			// Ajouter le tableau à une liste
			Tableau.add(tableau);
			// Ajouter le titre du tableau à l'autre liste 
			TitreTableau.addElement(tableau.getNomTableau());
		}
		// Ajouter les titres de tableau à la liste
		lstTableau = new JList<String>(TitreTableau);
		// Ajouter un écouteur à la liste
		lstTableau.addListSelectionListener(new ListSelectionListener() {
			// L'élément séléctionné a changé
			public void valueChanged(ListSelectionEvent e) {
				if (!e.getValueIsAdjusting()) {
					// Récupérer le nom du tableau sélectionné
					String ElementSelectionne = lstTableau.getSelectedValue();
					// Récupérer l'indice du tableau sélectionné
					int indice = lstTableau.getSelectedIndex();
					// Si le tableau n'est pas null
					if (ElementSelectionne != null) {
						// Récupérer le tableau
						ModeleTableau TableauChoisit = Tableau.get(indice);
						
						
						//-------------Cathy MARTIN et  Corentin DAROWNY -------------
						VueTableau TableauAffiche = new VueTableau(TableauChoisit);
						ModeleListe listeNull = new ModeleListe("");
						VueCreeListe VueCreeListe = new VueCreeListe(listeNull);;
						VueModifierTableau TableauModifie = new VueModifierTableau(TableauChoisit);
						ControleurTableau ecouteurTableau = new ControleurTableau(TableauChoisit, TableauAffiche, TableauModifie, VueCreeListe);
						// Créer une instance de VueModifierTableau
						VueModifierTableau vueModifierTableau = new VueModifierTableau(TableauChoisit);
						//Pour Tableau
						// Lorsque l'on clique sur Modifier
						TableauAffiche.btnModifierTableauClick(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								ecouteurTableau.modifierTableau();
							}
						});

						// Lorsque l'on clique sur Ajouter une liste
						TableauAffiche.btnAjouterListeClick(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								ecouteurTableau.CreeListe();
							}
						});

						// Quand on clique sur Enregistrer
						TableauModifie.btnEnregistrerClick(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								ecouteurTableau.enregistrement();
							}
						});

						// Quand on clique sur Créé
						VueCreeListe.btnCreeClick(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								ecouteurTableau.cree();
							}
						});

						// Quand on clique sur Annuler
						VueCreeListe.btnAnnulerClick(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								ecouteurTableau.annuler();
							}
						});
						//---------------------------------------------------------
						
						
						// Ajouter la vue de membre à la fenêtre principale
						pnlVueTableau.add(TableauAffiche);


						// Si le panel contenant les vues de tableau n'est pas vie
						if (pnlVueTableau != null) {
							// Vider le panel du tableau précédemment 
							pnlVueTableau.removeAll();
							pnlVueTableau.revalidate();
							pnlVueTableau.repaint();
						}
						// Ajouter le tableau au panel
						pnlVueTableau = pnlVueTableau;
						pnlVueTableau.add(TableauAffiche);
						pnlVueTableau.revalidate();
						pnlVueTableau.repaint();
					} 
				}
			}
		});

		// Redimensionner la photo de profil
		Image PhotoRedimensionnee = modele.getCreateurProjet().getImgProfil().getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		ImageIcon PhotoDeProfil = new ImageIcon(PhotoRedimensionnee);

		// Remplir les labels avec les données
		btnMembre = new JButton (modele.getCreateurProjet().getNomMembre() + " " + modele.getCreateurProjet().getPrenomMembre());
		lblPhotoMembre = new JLabel(PhotoDeProfil);
		lblTitreProjet = new JLabel (modele.getNomProjet());

		// Appliquer le style de police
		btnMembre.setFont(POLICECORPS);
		btnAjouterParticipant.setFont(POLICECORPS);
		btnRafraichir.setFont(POLICECORPS);
		btnAjouterTableau.setFont(POLICECORPS);
		btnVoirParticipant.setFont(POLICECORPS);
		lblTitreProjet.setFont(POLICETITRE);
		lblLogo.setFont(new Font("Bitstream Vera Sans Mono", Font.BOLD, 50));

		// Mettre un fond au bandeau
		pnlInformation.setBackground(COULEURTHEME);
		pnlMembre.setBackground(COULEURTHEME);
		btnMembre.setBackground(COULEURTHEME);
		btnAjouterParticipant.setBackground(COULEURTHEME);
		btnRafraichir.setBackground(COULEURTHEME);
		btnAjouterTableau.setBackground(COULEURTHEME);
		btnVoirParticipant.setBackground(COULEURTHEME);

		// Appliquer la bordure aux boutons
		btnRafraichir.setBorder(BORDURE);
		btnAjouterParticipant.setBorder(BORDURE);
		btnVoirParticipant.setBorder(BORDURE);

		//Ajouter dans les panels
		pnlMembre.add(btnMembre);
		pnlMembre.add(lblPhotoMembre);
		pnlInformation.add(lblLogo);
		pnlInformation.add(lblTitreProjet);
		pnlInformation.add(pnlMembre);
		pnlBoutons.add(btnAjouterParticipant, BorderLayout.WEST);
		pnlBoutons.add(btnRafraichir, BorderLayout.CENTER);
		pnlBoutons.add(btnVoirParticipant, BorderLayout.EAST);
		pnlBoutonPlus.add(btnAjouterTableau);
		pnlBoutonPlus.add(new JLabel());
		pnlBandeauBoutons.add(pnlBoutonPlus);
		pnlBandeauBoutons.add(pnlBoutons);
		pnlGeneral.add(lstTableau);
		pnlGeneral.add(pnlVueTableau);
		setLayout(new BorderLayout());
		add(pnlInformation, BorderLayout.NORTH);
		add(pnlGeneral, BorderLayout.CENTER);
		add(pnlBandeauBoutons, BorderLayout.SOUTH);
	}



	//---------------------------------
	// METHODES
	//---------------------------------
	/**
	 * Ajouter un écouteur au bouton destiné au profil.
	 * @param ecouteur L'écouteur
	 **/
	public void btnMembreClick(ActionListener ecouteur) {
		btnMembre.addActionListener(ecouteur);
	}

	/**
	 * Ajouter un écouteur au bouton "Ajouter des participants".
	 * @param un ecouteur
	 **/
	public void btnAjouterParticipantClick(ActionListener ecouteur) {
		btnAjouterParticipant.addActionListener(ecouteur);
	}

	/**
	 * Ajouter un écouteur au bouton "Rafraîchir".
	 * @param ecouteur L'écouteur
	 **/
	public void btnRafraichirClick(ActionListener ecouteur) {
		btnRafraichir.addActionListener(ecouteur);
	}

	/**
	 * Ajouter un écouteur au bouton "+".
	 * @param ecouteur L'écouteur
	 **/
	public void btnAjouterTableauClick(ActionListener ecouteur) {
		btnAjouterTableau.addActionListener(ecouteur);
	}

	/**
	 * Ajouter un écouteur au bouton "Voir les participants".
	 * @param ecouteur L'écouteur
	 **/
	public void btnVoirParticipantClick(ActionListener ecouteur) {
		btnVoirParticipant.addActionListener(ecouteur);
	}

	/**
	 * Mettre à jour la photo de profil
	 **/
	public void miseAJourPhoto() {
		// Redimensionner la photo de profil
		Image PhotoRedimensionnee = modele.getCreateurProjet().getImgProfil().getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		// Convertir l'image en icon
		ImageIcon PhotoDeProfil = new ImageIcon(PhotoRedimensionnee);
		// Ajouter l'image au label
		lblPhotoMembre.setIcon(PhotoDeProfil);
	}

	/**
	 * Mettre à jour la liste de tableau
	 **/
	public void miseAJourTableau(ModeleTableau tableau) {
		//Ajouter le titre du tableau chosit à la liste
		TitreTableau.addElement(tableau.getNomTableau());
		//Ajouter le tableau à la liste
		Tableau.add(tableau);
		// Mettre à jour le modèle de la JList avec le nouveau modèle
		lstTableau.setModel(TitreTableau);
	}
}
