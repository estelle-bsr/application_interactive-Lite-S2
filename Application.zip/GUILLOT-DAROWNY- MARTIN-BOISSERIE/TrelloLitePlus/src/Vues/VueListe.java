package Vues;

import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.Border;
import Modeles.*;

/**
 *
 *
 *         La classe VueListe est une vue qui affiche les informations d'une
 *         Liste.
 *         Elle permet également d'ajouter des écouteurs pour les actions de
 *         modification de la liste et d'ajout de carte.
 * 
 *         Elle est utilisée pour afficher une liste dans le tableau.
 * @author Corentin DAROWNY 
 */

public class VueListe extends JPanel {

	/******************
	 ** ATTRIBUTS **
	 ******************/
	private ModeleListe liste;
	private JLabel lblNomListe;
	private JButton btnModifier;
	private JButton btnAjouterCarte;
	private JButton btnSupprimerListe;
	public JPanel pnlPanneau;

	/**********************
	 ** CONSTRUCTEUR **
	 **********************/

	/**
	 * Constructeur de la classe VueListe.
	 * Crée une vue pour afficher les informations d'une liste.
	 * 
	 * @param Liste la liste à afficher
	 */
	public VueListe(ModeleListe Liste) {
		// Mémoriser le modèle sur lequel ce panel est une vue
		this.liste = Liste;

		setLayout(new GridBagLayout());

		// Créer le panneau pour le titre de la Liste
		JPanel pnlTitre = new JPanel(new GridBagLayout());
		lblNomListe = new JLabel(liste.getNomListe().toUpperCase());
		lblNomListe.setFont(new Font("Arial", Font.BOLD, 20)); // l'estetique du titre
		GridBagConstraints gbcTitre = new GridBagConstraints();
		gbcTitre.gridx = 0;
		gbcTitre.gridy = 0;
		gbcTitre.anchor = GridBagConstraints.NORTH;
		pnlTitre.add(lblNomListe, gbcTitre);

		// Créer le boutton de modification de la liste
		btnModifier = new JButton("Modifier");

		// Créer le boutton pour Ajouter une carte
		btnAjouterCarte = new JButton("Ajouter une carte");

		// Créer le boutton pour supprimer la liste
		btnSupprimerListe = new JButton("Supprimer");

		pnlPanneau = new JPanel(new GridBagLayout());

		// Ajouter les sous-panneaux au panneau principal
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.PAGE_START; // indique que le composant doit être ancré en haut de la cellule
		gbc.anchor = GridBagConstraints.LINE_START; // indique que le composant doit être ancré à gauche de la cellule
		gbc.insets = new Insets(62, 5, 63, 5);
		pnlPanneau.add(pnlTitre, gbc);

		// Bouton modifier
		gbc.gridy = 1;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.insets = new Insets(0, 0, 0, 0);
		pnlPanneau.add(btnModifier, gbc);

		// Bouton ajouter Carte
		gbc.gridy = 3;
		gbc.anchor = GridBagConstraints.CENTER;
		gbc.insets = new Insets(0, 0, 0, 0);
		pnlPanneau.add(btnAjouterCarte, gbc);

		// créer une bordure de trait noir et largeur minimale 1
		Border lineborder = BorderFactory.createLineBorder(Color.black, 1);

		// associer à un JPanel
		pnlPanneau.setBorder(lineborder);
		add(pnlPanneau);

	}

	/******************
	 ** METHODES **
	 ******************/

	/**
	 * Ajoute un écouteur pour l'action de cliquer sur le bouton "Modifier".
	 * 
	 * @param ecouteur l'écouteur à ajouter
	 */
	public void btnModifierClick(ActionListener ecouteur) {
		btnModifier.addActionListener(ecouteur);
	}

	/**
	 * Ajoute un écouteur pour l'action de cliquer sur le bouton "Ajouter une
	 * carte".
	 * 
	 * @param ecouteur l'écouteur à ajouter
	 */
	public void btnAjouterCarteClick(ActionListener ecouteur) {
		btnAjouterCarte.addActionListener(ecouteur);
	}

	/**
	 * Met à jour l'affichage de la vue de la liste avec les informations de la
	 * liste actuelle.
	 */
	public void updateVueListe() {
		lblNomListe.setText(liste.getNomListe().toUpperCase());
	}

}
