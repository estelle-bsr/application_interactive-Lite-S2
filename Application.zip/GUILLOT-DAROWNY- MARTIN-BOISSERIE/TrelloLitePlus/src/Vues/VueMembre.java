package Vues;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import Modeles.*;

/**
 * La classe VueMembre est la vue graphique d'un membre.
 * 
 * @author Estelle BOISSERIE
 **/
public class VueMembre extends JPanel {
	//---------------------------------
	// ATTRIBUTS
	//---------------------------------
	private ModeleMembre modele;

	private JLabel lblNomMembre;
	private JLabel lblPrenomMembre;
	private JLabel lblMailMembre;
	private JLabel lblMotdepasseMembre;
	private JLabel lblPhoto;
	private JLabel lblNom = new JLabel("Nom : "                 );
	private JLabel lblPrenom = new JLabel("Prénom : "           );
	private JLabel lblMail = new JLabel("Adresse mail : "       );
	private JLabel lblMotdepasse  = new JLabel("Mot de passe : ");

	private JButton btnModifier  = new JButton("Modifier"               );
	private JButton btnRafraichir = new JButton("Rafraîchir"            );
	private JButton btnCommentaire = new JButton("Voir mes commentaires");
	private JButton btnProjet = new JButton("Voir mes projets"          );
	private JButton btnCarte = new JButton("Voir mes cartes"            );

	private JPanel pnlNom  = new JPanel(new GridLayout(1, 2)      );
	private JPanel pnlPrenom = new JPanel(new GridLayout(1, 2)    );
	private JPanel pnlMail = new JPanel(new GridLayout(1, 2)      );
	private JPanel pnlMotdepasse = new JPanel(new GridLayout(1, 2));
	private JPanel pnlNomPrenom = new JPanel(new GridLayout(1, 2) );
	private JPanel pnlGeneral = new JPanel (new GridLayout(4, 1)  );
	private JPanel pnlBoutons = new JPanel (new GridLayout(5,1)   );
	private JPanel pnlImage = new JPanel (new FlowLayout()        );

	private final static Font POLICETITRE = new Font("Arial", Font.BOLD, 20            );
	private final static Font POLICECORPS = new Font("New Times Romans", Font.PLAIN, 15);

	private final static Color COULEURBOUTON = new Color(147, 112, 219);

	private final static int MARGE = 20;



	//---------------------------------
	// CONSTRUCTEUR
	//---------------------------------
	/**
	 * Constructeur de la classe VueMembre. 
	 * Le constructeur permet de créer une instcne de la classe VueMembre qui représente graphique la vue d'un membre prit en paramètre.
	 * 
	 * @param modele Le membre représenté dans la vue
	 **/
	public VueMembre(ModeleMembre modele) {
		// Mémoriser le modèle(membre) sur lequel ce panel est une vue
		this.modele = modele;

		//Créer les labels dédiés aux informations personnelles du membre
		lblNomMembre = new JLabel(modele.getNomMembre());
		lblPrenomMembre = new JLabel(modele.getPrenomMembre());
		lblMailMembre = new JLabel(modele.getMailMembre());
		lblMotdepasseMembre = new JLabel(modele.getMotdepasseMembreMasque());

		// Appliquer les styles de police
		lblNom.setFont(POLICETITRE);
		lblNomMembre.setFont(POLICECORPS);
		lblPrenom.setFont(POLICETITRE);
		lblPrenomMembre.setFont(POLICECORPS);
		lblMail.setFont(POLICETITRE);
		lblMailMembre.setFont(POLICECORPS);
		lblMotdepasse.setFont(POLICETITRE);
		lblMotdepasseMembre.setFont(POLICECORPS);
		btnModifier.setFont(POLICETITRE);
		btnRafraichir.setFont(POLICETITRE);
		btnCommentaire.setFont(POLICETITRE);
		btnProjet.setFont(POLICETITRE);
		btnCarte.setFont(POLICETITRE);

		// Appliquer la couleur aux boutons
		btnModifier.setBackground(COULEURBOUTON);
		btnRafraichir.setBackground(COULEURBOUTON);
		btnCommentaire.setBackground(COULEURBOUTON);
		btnProjet.setBackground(COULEURBOUTON);
		btnCarte.setBackground(COULEURBOUTON);

		//Appliquer les marges aux pannels
		pnlBoutons.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, MARGE));
		pnlGeneral.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, MARGE));

		//Ajouter la photo de profil dans le label
		lblPhoto = new JLabel(modele.getImgProfil());

		// Ajouter les labels dans les panels
		pnlNom.add(lblNom);
		pnlNom.add(lblNomMembre);
		pnlPrenom.add(lblPrenom);
		pnlPrenom.add(lblPrenomMembre);
		pnlNomPrenom.add(pnlNom);
		pnlNomPrenom.add(pnlPrenom);
		pnlGeneral.add(pnlNomPrenom);
		pnlMail.add(lblMail);
		pnlMail.add(lblMailMembre);
		pnlMotdepasse.add(lblMotdepasse);
		pnlMotdepasse.add(lblMotdepasseMembre);
		pnlBoutons.add(btnModifier);
		pnlBoutons.add(btnRafraichir);
		pnlBoutons.add(btnCommentaire);
		pnlBoutons.add(btnProjet);
		pnlBoutons.add(btnCarte);
		pnlImage.add(lblPhoto);
		pnlGeneral.add(pnlImage);
		pnlGeneral.add(pnlNomPrenom);
		pnlGeneral.add(pnlMail);
		pnlGeneral.add(pnlMotdepasse);
		setLayout(new BorderLayout());
		add(pnlGeneral, BorderLayout.EAST);
		add(pnlBoutons, BorderLayout.WEST);
	}



	//---------------------------------
	// METHODES
	//---------------------------------
	/**
	 * Ajouter un écouteur au bouton "Modifier".
	 * @param ecouteur L'écouteur
	 **/
	public void btnModifierClick(ActionListener ecouteur) {
		btnModifier.addActionListener(ecouteur);
	}

	/**
	 * Ajouter un écouteur au bouton "Rafraichir".
	 * @param ecouteur L'écouteur
	 **/
	public void btnRafraichirClick(ActionListener ecouteur) {
		btnRafraichir.addActionListener(ecouteur);
	}

	/**
	 * Ajouter un écouteur au bouton "Voir mes commentaires".
	 * @param ecouteur L'écouteur
	 **/public void btnCommentaireClick(ActionListener ecouteur) {
		 btnCommentaire.addActionListener(ecouteur);
	 }

	 /**
	  * Ajouter un écouteur au bouton "Voir mes projets"
	  * @param ecouteur L'écouteur
	  **/
	 public void btnProjetClick(ActionListener ecouteur) {
		 btnProjet.addActionListener(ecouteur);
	 }

	 /**
	  * Ajouter un écouteur au bouton "Voir mes cartes"
	  * @param ecouteur L'écouteur
	  **/
	 public void btnCarteClick(ActionListener ecouteur) {
		 btnCarte.addActionListener(ecouteur);
	 }

	 /**
	  * Mettre à jour la vue
	  * Inspiré par Cathy MARTIN
	  * 
	  * @param membre Le membre dont on met à jour le profil
	  **/
	 public void Redessiner(ModeleMembre membre) {
		 // Afficher le nouveau nom du membre
		 setNomMembre(membre.getNomMembre());
		 // Afficher le nouveau prénom du membre
		 setPrenomMembre(membre.getPrenomMembre());
		 // Afficher la nouvelle adresse mail du membre
		 setMailMembre(membre.getMailMembre());
		 // Afficher le nouveau mot de passe du membre sous forme masqué
		 setMotdepasseMembre(membre.getMotdepasseMembreMasque());
		 // Afficher la nouvelle photo de profil du membre
		 setPhotoMembre(membre.getImgProfil());
	 }



	 //---------------------------------
	 // ACCESSEURS
	 //---------------------------------
	 /**
	  * Avoir le nom à un membre
	  * @return Le nom du membre
	  **/
	 public String getNomMembre() {
		 return lblNomMembre.getText();
	 }
	 /**
	  * Avoir le prénom d'un membre
	  * @return Le prénnom du membre
	  **/
	 public String getPrenomMembre() {
		 return lblPrenomMembre.getText();
	 }
	 /**
	  * Avoir le mail du membre 
	  * @return L'adresse mail du membre
	  **/
	 public String getMailMembre() {
		 return lblMailMembre.getText();
	 }
	 /**
	  * Avoir le mot de passe du membre
	  * @return Le mot de passe du membre
	  **/
	 public String getMotdepasseMembre() {
		 return lblMotdepasseMembre.getText();
	 }
	 /**
	  * Modifier le nom d'un membre
	  * @param nom Le nouveau nom du membre
	  **/
	 public void setNomMembre(String nom) {
		 this.lblNomMembre.setText(nom);
	 }
	 /**
	  * Modifier le prénom d'un membre
	  * @param prenom Le nouveau prénom du membre
	  **/
	 public void setPrenomMembre(String prenom) {
		 this.lblPrenomMembre.setText(prenom);;
	 }
	 /**
	  * Modifier l'adresse mail d'un membre
	  * @param mail La nouvelle adresse mail du membre
	  **/
	 public void setMailMembre(String mail) {
		 this.lblMailMembre.setText(mail);
	 }
	 /**
	  * Modifier le mot de passe d'un membre
	  * @param mot de passe Le nouveau mot de passe du membre
	  **/
	 public void setMotdepasseMembre(String motdepasse) {
		 this.lblMotdepasseMembre.setText(motdepasse);;
	 }
	 /**
	  * Modifier la photo de profil d'un membre
	  * @param photo La nouvelle photo de profil du membre
	  **/
	 public void setPhotoMembre(ImageIcon photo) {
		 lblPhoto.setIcon(photo);
	 }
}
