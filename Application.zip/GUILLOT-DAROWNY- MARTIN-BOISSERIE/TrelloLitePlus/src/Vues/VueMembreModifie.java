package Vues;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import Modeles.*;

/**
 * Cette classe est la classe VueMembreModifie.
 * Elle représente la vue graphique des modifications du profil d'un membre.
 * Elle affichée lorsque le membre va dans son profil, représenter par VueMembre, et clique sur le bouton "Modifier".
 * 
 * @author Estelle BOISSERIE
 *
 **/
public class VueMembreModifie extends JPanel {
	//---------------------------------
	// ATTRIBUTS
	//---------------------------------
	private ModeleMembre modele;

	private JLabel lblNom = new JLabel("Nom : "                                               );
	private JLabel lblPrenom = new JLabel("Prénom : "                                         );
	private JLabel lblMail = new JLabel("Adresse mail : "                                     );
	private JLabel lblAncienMotdepasse = new JLabel("Mot de passe actuel : "                  );
	private JLabel lblNouveauMotdepasse = new JLabel("Nouveau mot de passe : "                );
	private JLabel lblMotdepasseConfirme = new JLabel("Confimer votre nouveau mot de passe : ");

	private JTextField txtNomMembre = new JTextField(10             );
	private JTextField txtPrenomMembre = new JTextField(10          );
	private JTextField txtMailMembre = new JTextField(10            );
	private JTextField txtAncienMotdepasseMembre = new JTextField(10);

	private JPasswordField txtNouveauMotdepasseMembre = new JPasswordField(10 );
	private JPasswordField txtMotdepasseConfirmeMembre = new JPasswordField(10);

	private JButton btnSauvegarde = new JButton("Sauvegarder"           );
	private JButton btnPhoto = new JButton("Modifier la photo de profil");

	private JPanel pnlNom = new JPanel( new FlowLayout()               );
	private JPanel pnlPrenom = new JPanel( new FlowLayout()            );
	private JPanel pnlMail = new JPanel( new FlowLayout()              );
	private JPanel pnlMotdepasses = new JPanel (new GridLayout(3, 2)   );
	private JPanel pnlAncienMotdepasse = new JPanel( new FlowLayout()  );
	private JPanel pnlNouveauMotdepasse = new JPanel( new FlowLayout() );
	private JPanel pnlMotdepasseConfirme = new JPanel( new FlowLayout());
	private JPanel pnlNomPrenom = new JPanel (new GridLayout(1, 2)     );
	private JPanel pnlGeneral = new JPanel (new GridLayout(4, 1)       );
	private JPanel pnlBouton= new JPanel (new BorderLayout()           );

	private final static Font POLICETITRE = new Font("Arial", Font.BOLD, 20   );
	private final static Font POLICECORPS = new Font("Console", Font.PLAIN, 15);

	private final static Color COULEURBOUTON = new Color(147, 112, 219);



	//---------------------------------
	// CONSTRUCTEUR
	//---------------------------------
	/**
	 * Constructeur de la classe VueMembreModifie.
	 * Ce constructeur permet de créer une instance de VueMembreModifie qui représente la vue de modification du profil d'un membre (celui en paramètre).
	 * 
	 * @param modele Le membre dont le profile est ou va être modifié.
	 **/
	public VueMembreModifie(ModeleMembre modele) {
		// Mémoriser le modèle(membre) sur lequel ce panel est une vue
		this.modele = modele;

		// Appliquer les styles de police
		lblNom.setFont(POLICETITRE);
		lblPrenom.setFont(POLICETITRE);
		lblMail.setFont(POLICETITRE);
		lblAncienMotdepasse.setFont(POLICETITRE);
		lblNouveauMotdepasse.setFont(POLICETITRE);
		lblMotdepasseConfirme.setFont(POLICETITRE);
		btnSauvegarde.setFont(POLICETITRE);
		txtNomMembre.setFont(POLICECORPS);
		txtPrenomMembre.setFont(POLICECORPS);
		txtMailMembre.setFont(POLICECORPS);
		txtAncienMotdepasseMembre.setFont(POLICECORPS);
		txtNouveauMotdepasseMembre.setFont(POLICECORPS);
		txtMotdepasseConfirmeMembre.setFont(POLICECORPS);
		btnSauvegarde.setFont(POLICETITRE);
		btnPhoto.setFont(POLICETITRE);

		// Appliquer la couleur
		btnSauvegarde.setBackground(COULEURBOUTON);
		btnPhoto.setBackground(COULEURBOUTON);

		// Ajouter les labels dans les panels
		pnlNom.add(lblNom);
		pnlNom.add(txtNomMembre);
		pnlPrenom.add(lblPrenom);
		pnlPrenom.add(txtPrenomMembre);
		pnlNomPrenom.add(pnlNom);
		pnlNomPrenom.add(pnlPrenom);
		pnlGeneral.add(pnlNomPrenom);
		pnlMail.add(lblMail);
		pnlMail.add(txtMailMembre);
		pnlAncienMotdepasse.add(lblAncienMotdepasse);
		pnlAncienMotdepasse.add(txtAncienMotdepasseMembre);
		pnlNouveauMotdepasse.add(lblNouveauMotdepasse);
		pnlNouveauMotdepasse.add(txtNouveauMotdepasseMembre);
		pnlMotdepasseConfirme.add(lblMotdepasseConfirme);
		pnlMotdepasseConfirme.add(txtMotdepasseConfirmeMembre);
		pnlMotdepasses.add(pnlAncienMotdepasse);
		pnlMotdepasses.add(pnlNouveauMotdepasse);
		pnlMotdepasses.add(pnlMotdepasseConfirme);
		pnlBouton.add(btnSauvegarde, BorderLayout.EAST);
		pnlBouton.add(btnPhoto, BorderLayout.WEST);
		pnlGeneral.add(pnlNomPrenom);
		pnlGeneral.add(pnlMail);
		pnlGeneral.add(pnlMotdepasses);
		pnlGeneral.add(pnlBouton);
		add(pnlGeneral);
	}



	//---------------------------------
	// METHODES
	//---------------------------------
	/**
	 * Ajouter un écouteur au bouton "Sauvegarder".
	 * @param ecouteur L'écouteur
	 **/
	public void btnSauvegardeClick(ActionListener ecouteur) {
		btnSauvegarde.addActionListener(ecouteur);
	}

	/**
	 * Ajouter un écouteur au bouton "Modifier la photo de profil".
	 * @param ecouteur L'écouteur
	 **/
	public void btnPhotoClick(ActionListener ecouteur) {
		btnPhoto.addActionListener(ecouteur);	
	}

	/**
	 * Vider les cases de saisies de texte.
	 **/
	public void viderCase() {
		// Vider la case de saisie de nom
		setNomMembre("");
		// Vider la case de saisie de prénom
		setPrenomMembre("");
		// Vider la case de saisie d'adresse mail
		setMailMembre("");
		// Vider la case de saisie du mot de passe actuel
		setAncienMotdepasse("");
		// Vider la case de saise de nouveau mot de passe
		setNouveauMotdepasse("");
		// Vider la case de saisie de confirmation du nouveau mot de passe
		setMotdepasseConfirme("");
	}



	//---------------------------------
	// ACCESSEURS
	//---------------------------------
	/**
	 * Avoir le nom du membre
	 * @return Le nom du membre
	 **/
	public String getNomMembre() {
		return txtNomMembre.getText();
	}
	/**
	 * Avoir le prénom du membre
	 * @return Le prénom du membre
	 **/
	public String getPrenomMembre() {
		return txtPrenomMembre.getText();
	}
	/**
	 * Avoir le mail du membre
	 * @return Le mail du membre
	 **/
	public String getMailMembre() {
		return txtMailMembre.getText();
	}
	/**
	 * Avoir l'ancien mot de passe du membre
	 * @return L'ancien mot de passe du membre
	 **/
	public String getAncienMotdepasse() {
		return txtAncienMotdepasseMembre.getText().trim();
	}
	/**
	 * Avoir le nouveau mot de passe du membre
	 * @return Le nouveau mot de passe du membre
	 **/
	public String getNouveauMotdepasse() {
		char[] motdepasse = txtNouveauMotdepasseMembre.getPassword();
		return new String(motdepasse);
	}
	/**
	 * Avoir le mot de passe de confirmation du membre
	 * @return Le mot de passe de confirmation  du membre
	 **/
	public String getMotdepasseConfirme() {
		char[] motdepasse = txtMotdepasseConfirmeMembre.getPassword();
		return new String(motdepasse);
	}
	/**
	 * Modifier la case de saisie du nom d'un membre
	 * @param nom Le nouveau contenu
	 **/
	public void setNomMembre(String nom) {
		txtNomMembre.setText(nom);
	}
	/**
	 * Modifier la case de saisie du prénom d'un membre
	 * @param prenom Le nouveau contenu
	 **/
	public void setPrenomMembre(String prenom) {
		txtPrenomMembre.setText(prenom);
	}
	/**
	 * Modifier la case de saisie de l'adresse mail d'un membre
	 * @param mail Le nouveau contenu
	 **/
	public void setMailMembre(String mail) {
		txtMailMembre.setText(mail);
	}
	/**
	 * Modifier la case de saisie du mot de passe actuel d'un membre
	 * @param motdepasse Le nouveau contenu
	 **/
	public void setAncienMotdepasse(String motdepasse) {
		txtAncienMotdepasseMembre.setText(motdepasse);
	}
	/**
	 * Modifier la case de saisie du nouveau mot de passe d'un membre
	 * @param motdepasse Le nouveau contenu
	 **/
	public void setNouveauMotdepasse(String motdepasse) {
		txtNouveauMotdepasseMembre.setText(motdepasse);
	}
	/**
	 * Modifier la case de saisie du mot de passe de confirmation d'un membre
	 * @param motdepasse Le nouveau contenu
	 **/
	public void setMotdepasseConfirme(String motdepasse) {
		txtMotdepasseConfirmeMembre.setText(motdepasse);
	}
}
