package Vues;

import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;
import Modeles.*;

/**
 * @author Cathy MARTIN
 *
 *         La classe VueModifierCarte représente une vue pour modifier une
 *         carte.
 *         Elle affiche les champs de modification tels que le titre, la
 *         description, la date limite et le statut de la carte.
 *         Les utilisateurs peuvent saisir les nouvelles valeurs pour ces champs
 *         et enregistrer les modifications.
 *         (Ils ont également la possibilité de supprimer la carte.)
 * 
 */

public class VueModifierCarte extends JPanel {
	/******************
	 ** ATTRIBUTS **
	 ******************/
	private ModeleCarte carte;
	private JTextField txtTitre;
	private JTextArea txtDescription; // pouvoir mettre du text su plusieur ligne
	private JTextField txtDateLimite;
	private JComboBox<String> cmbStatut;
	private JButton btnEnregistrer;
	private JButton btnSupprimer;

	/**********************
	 ** CONSTRUCTEUR **
	 **********************/

	/**
	 * Constructeur de la classe VueModifierCarte.
	 * Crée une vue pour pouvoir modifier une carte.
	 * 
	 * @param carte La carte à modifier.
	 */
	public VueModifierCarte(ModeleCarte carte) {
		this.carte = carte;

		setLayout(new BorderLayout());

		JPanel pnlModif = new JPanel(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.LINE_START;
		gbc.insets = new Insets(5, 5, 5, 5); // espace entre le JPanel et la JText

		// Titre
		JLabel lblTitre = new JLabel("Titre:");
		pnlModif.add(lblTitre, gbc);

		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		txtTitre = new JTextField(carte.getNomCarte());
		pnlModif.add(txtTitre, gbc);

		// Description
		gbc.gridx = 0;
		gbc.gridy = 1;
		JLabel lblDescription = new JLabel("Description:");
		pnlModif.add(lblDescription, gbc);

		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		txtDescription = new JTextArea(carte.getDescriptionCarte());
		txtDescription.setRows(3);
		JScrollPane scrollPane = new JScrollPane(txtDescription);
		pnlModif.add(scrollPane, gbc);

		// Date limite
		gbc.gridx = 0;
		gbc.gridy = 2;
		JLabel lblDateLimite = new JLabel("Date limite:");
		pnlModif.add(lblDateLimite, gbc);

		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		txtDateLimite = new JTextField(carte.getDateEcheanceCarte());
		pnlModif.add(txtDateLimite, gbc);

		// Statut
		gbc.gridx = 0;
		gbc.gridy = 3;
		JLabel lblStatut = new JLabel("Statut:");
		pnlModif.add(lblStatut, gbc);

		gbc.gridx = 1;
		gbc.gridy = 3;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		String[] statuts = { "Pas commencé", "En cours", "Fini" };
		cmbStatut = new JComboBox<>(statuts);
		cmbStatut.setSelectedItem(carte.getStatutCarte());
		pnlModif.add(cmbStatut, gbc);

		// Bouton Enregistrer
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.gridwidth = 2; // Le composant occupe deux cellules horizontalement
		btnEnregistrer = new JButton("Enregistrer");
		pnlModif.add(btnEnregistrer, gbc);

		// Bouton Supprimer
		btnSupprimer = new JButton("Supprimer");

		// Ajout des composants au panneau principal
		add(pnlModif, BorderLayout.CENTER);
		add(btnSupprimer, BorderLayout.SOUTH);
	}

	/******************
	 ** METHODES **
	 ******************/

	/**
	 * Ajoute un écouteur pour l'action de cliquer sur le bouton "Enregistrer".
	 * 
	 * @param ecouteur l'écouteur à ajouter
	 */
	public void btnEnregistrerClick(ActionListener ecouteur) {
		btnEnregistrer.addActionListener(ecouteur);
	}

	/**
	 * Ajoute un écouteur pour l'action de cliquer sur le bouton "Supprimer".
	 *
	 * @param ecouteur l'écouteur à ajouter pour l'action de suppression
	 */
	public void btnSupprimerClick(ActionListener ecouteur) {
		btnSupprimer.addActionListener(ecouteur);
	}

	/******************
	 ** ACCESSEURS **
	 *******************/
	/**
	 * Récupère le titre saisi dans le champ de texte.
	 * 
	 * @return Le titre de la carte.
	 */
	public String getTitre() {
		return txtTitre.getText();
	}

	/**
	 * Récupère la description saisie dans le champ de texte.
	 * 
	 * @return La description de la carte.
	 */
	public String getDescription() {
		return txtDescription.getText();
	}

	/**
	 * Récupère la date limite saisie dans le champ de texte.
	 * 
	 * @return La date limite de la carte.
	 */
	public String getDateLimite() {
		return txtDateLimite.getText();
	}

	/**
	 * Récupère le statut sélectionné dans la liste déroulante.
	 * 
	 * @return Le statut de la carte.
	 */
	public String getStatut() {
		return (String) cmbStatut.getSelectedItem();
	}
}
