package Vues;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import Modeles.*;

/**
 * @author Darowny Corentin et Martin Cathy
 *
 *         La classe VueModifierListe représente une vue pour modifier une
 *         liste.
 *         Elle affiche le champ de modification pour le titre.
 *         Les utilisateurs peuvent saisir la nouvelle valeur pour ce champ et
 *         enregistrer la modification.
 *         (Ils ont également la possibilité de supprimer la liste.)
 * 
 */

public class VueModifierListe extends JPanel {
	/******************
	 ** ATTRIBUTS **
	 ******************/
	private ModeleListe liste;
	private JTextField txtTitreListe;
	private JButton btnEnregistrer;
	private JButton btnSupprimer;

	/**********************
	 ** CONSTRUCTEUR **
	 **********************/

	/**
	 * Constructeur de la classe VueModifierListe.
	 * Crée vue de pour pouvoir modifier une liste.
	 * 
	 * @param liste La liste à modifier.
	 */
	public VueModifierListe(ModeleListe liste) {
		this.liste = liste;

		setLayout(new BorderLayout());

		JPanel pnlModif = new JPanel(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.LINE_START;
		gbc.insets = new Insets(5, 5, 5, 5); // espace entre le JPanel et la JText

		// Titre
		JLabel lblTitre = new JLabel("Titre:");
		pnlModif.add(lblTitre, gbc);

		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		txtTitreListe = new JTextField(liste.getNomListe());
		pnlModif.add(txtTitreListe, gbc);

		// Bouton Enregistrer
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 2; // Le composant occupe deux cellules horizontalement
		btnEnregistrer = new JButton("Enregistrer");
		pnlModif.add(btnEnregistrer, gbc);

		// Bouton Supprimer
		btnSupprimer = new JButton("Supprimer");

		// Ajout des composants au panneau principal
		add(pnlModif, BorderLayout.CENTER);
		add(btnSupprimer, BorderLayout.SOUTH);
	}

	/******************
	 ** METHODES **
	 ******************/

	/**
	 * Ajoute un écouteur pour l'action de cliquer sur le bouton "Enregistrer".
	 * 
	 * @param ecouteur l'écouteur à ajouter
	 */
	public void btnEnregistrerClick(ActionListener ecouteur) {
		btnEnregistrer.addActionListener(ecouteur);
	}

	/**
	 * Ajoute un écouteur pour l'action de cliquer sur le bouton "Supprimer".
	 *
	 * @param ecouteur l'écouteur à ajouter pour l'action de suppression
	 */
	public void btnSupprimerClick(ActionListener ecouteur) {
		btnSupprimer.addActionListener(ecouteur);
	}

	/******************
	 ** ACCESSEURS **
	 *******************/

	/**
	 * Récupère le titre saisi dans le champ de texte.
	 * 
	 * @return Le titre de la liste.
	 */
	public String getTitre() {
		return txtTitreListe.getText();
	}

}
