
package Vues;

import Modeles.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Cette classe est la vue de modification d'un projet
 * @author Antonin GUILLOT
 *
 */
public class VueModifierProjet extends JPanel {
	/******************
	 ** ATTRIBUTS **
	 ******************/
	private JTextField txtTitre; 
	private JTextArea txtDescription; //pouvoir mettre du texte sur plusieurs lignes
	private JTextField txtDateEcheance;
	private JButton btnEnregistrer;
	private JButton btnAnnuler;

	/******************
	 ** CONSTRUCTEUR **
	 ******************/
	/**
	 * Créer une instance de la classe VueModifierProjet afin de faire la vue
	 */
	public VueModifierProjet() {


		setLayout(new BorderLayout());

		JPanel pnlCreation = new JPanel(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.LINE_START;
		gbc.insets = new Insets(5, 5, 5, 5);  // espace entre le JPanel et la JText

		// Titre
		JLabel lblTitre = new JLabel("Titre:");
		pnlCreation.add(lblTitre, gbc);

		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		setTxtTitre(new JTextField(10));
		pnlCreation.add(getTxtTitre(), gbc);

		// Description
		gbc.gridx = 0;
		gbc.gridy = 1;
		JLabel lblDescription = new JLabel("Description:");
		pnlCreation.add(lblDescription, gbc);
		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		txtDescription = new JTextArea();
		txtDescription.setRows(3);
		JScrollPane scrollPane = new JScrollPane(txtDescription);
		pnlCreation.add(scrollPane, gbc);

		// Date limite
		gbc.gridx = 0;
		gbc.gridy = 2;
		JLabel lblDateEcheance = new JLabel("Date echéance:");
		pnlCreation.add(lblDateEcheance, gbc);

		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		txtDateEcheance = new JTextField(10);
		pnlCreation.add(txtDateEcheance, gbc);




		// Bouton Enregistrer
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.gridwidth = 2; // Le composant occupe deux cellules horizontalement
		btnEnregistrer = new JButton("Enregistrer");
		pnlCreation.add(btnEnregistrer, gbc);

		// Bouton annuler
		gbc.gridx = 0;
		gbc.gridy = 5;
		gbc.gridwidth = 2; // Le composant occupe deux cellules horizontalement
		setBtnAnnuler(new JButton("Annuler"));
		pnlCreation.add(getBtnAnnuler(), gbc);

		// Ajout des composants au panneau principal
		add(pnlCreation, BorderLayout.CENTER);

	}


	/******************
	 ** METHODES **
	 ******************/

	/**
	 *  Ajouter l'écouteur au bouton enregistrer
	 * @param un ecouteur
	 */
	public void btnEnregistrerClick(ActionListener ecouteur) {
		btnEnregistrer.addActionListener(ecouteur);
	}

	/**
	 * Ajouter l'écouteur au bouton annuler
	 * @param un ecouteur
	 */

	public void btnAnnulerClick(ActionListener ecouteur) {
		getBtnAnnuler().addActionListener(ecouteur);
	}


	/******************
	 ** ACCESSEURS **
	 *******************/
	public String getTitre() {
		return getTxtTitre().getText();
	}

	public String getDescription() {
		return txtDescription.getText();
	}

	public String getDateEcheance() {
		return txtDateEcheance.getText();
	}


	public JTextArea getTxtDescription() {
		return txtDescription;
	}


	public void setTxtDescription(JTextArea txtDescription) {
		this.txtDescription = txtDescription;
	}


	public JTextField getTxtDateEcheance() {
		return txtDateEcheance;
	}


	public void setTxtDateEcheance(JTextField txtDateEcheance) {
		this.txtDateEcheance = txtDateEcheance;
	}


	public void setTxtTitre(JTextField txtTitre) {
		this.txtTitre = txtTitre;
	}


	public JTextField getTxtTitre() {
		return txtTitre;
	}


	public JButton getBtnAnnuler() {
		return btnAnnuler;
	}


	public void setBtnAnnuler(JButton btnAnnuler) {
		this.btnAnnuler = btnAnnuler;
	}
}
