package Vues;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import Modeles.*;

/**
 * @author Cathy MARTIN
 *
 *         La classe VueModifierTableau représente une vue pour modifier un
 *         tableau.
 *         Elle affiche le champ de modification pour le titre.
 *         Les utilisateurs peuvent saisir la nouvelle valeur pour ce champ et
 *         enregistrer la modification.
 *         (Ils ont également la possibilité de supprimer le tableau.)
 * 
 */

public class VueModifierTableau extends JPanel {
	/******************
	 ** ATTRIBUTS **
	 ******************/
	private ModeleTableau tableau;
	private JTextField txtTitreTableau;
	private JButton btnEnregistrer;
	private JButton btnSupprimer;

	/**********************
	 ** CONSTRUCTEUR **
	 **********************/

	/**
	 * Constructeur de la classe VueModifierTableau.
	 * Crée vue de pour pouvoir modifier un tableau.
	 * 
	 * @param tableau Le tableau à modifier.
	 */
	public VueModifierTableau(ModeleTableau tableau) {
		this.tableau = tableau;

		setLayout(new BorderLayout());

		JPanel pnlModif = new JPanel(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.LINE_START;
		gbc.insets = new Insets(5, 5, 5, 5); // espace entre le JPanel et la JText

		// Titre
		JLabel lblTitre = new JLabel("Titre:");
		pnlModif.add(lblTitre, gbc);

		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		txtTitreTableau = new JTextField(tableau.getNomTableau());
		pnlModif.add(txtTitreTableau, gbc);

		// Bouton Enregistrer
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 2; // Le composant occupe deux cellules horizontalement
		btnEnregistrer = new JButton("Enregistrer");
		pnlModif.add(btnEnregistrer, gbc);

		// Bouton Supprimer
		btnSupprimer = new JButton("Supprimer");

		// Ajout des composants au panneau principal
		add(pnlModif, BorderLayout.CENTER);
		add(btnSupprimer, BorderLayout.SOUTH);
	}

	/******************
	 ** METHODES **
	 ******************/

	/**
	 * Ajoute un écouteur pour l'action de cliquer sur le bouton "Enregistrer".
	 * 
	 * @param ecouteur l'écouteur à ajouter
	 */
	// Ajouter l'écouteur à la liste d'écouteur du bouton enregistrer
	public void btnEnregistrerClick(ActionListener ecouteur) {
		btnEnregistrer.addActionListener(ecouteur);
	}

	/******************
	 ** ACCESSEURS **
	 *******************/

	/**
	 * Récupère le titre saisi dans le champ de texte.
	 * 
	 * @return Le titre du tableau.
	 */
	public String getTitre() {
		return txtTitreTableau.getText();
	}

}
