package Vues;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import Modeles.*;

/**
 * Cette classe est la VueProjet qui est la vue graphique des projets. 
 * Elle représente les données de ModeleProjet
 * 
 * @author Antonin Guillot
 * @author Estelle BOISSERIE
 */
public class VueProjet extends JPanel {

	//---------------------------------
	// ATTRIBUTS
	//---------------------------------
	private JLabel lblLogo = new JLabel("TRELLO LITE +");

	private JButton btnCreer = new JButton("+");

	private JPanel pnlProjet = new JPanel(new FlowLayout());
	private JPanel pnlGlobal = new JPanel(new GridLayout(2,1));

	private final static Font POLICETITRE = new Font("Arial", Font.BOLD, 20);

	private final static Color COULEURBOUTON = new Color(147, 112, 219);

	//---------------------------------
	// CONSTRUCTEUR
	//---------------------------------
	/**
	 * Constructeur de la classe VueProjet. 
	 * Il permet de créer une instance de VueProjet qui est la vue graphique des projets.
	 **/
	public VueProjet () {
		// Appliquer une police d'éciture
		lblLogo.setFont(new Font("Arial", Font.BOLD, 50));
		btnCreer.setFont(POLICETITRE);

		// Appliquer un couleur de fond
		btnCreer.setBackground(COULEURBOUTON);
		setBackground(COULEURBOUTON);

		// Ajouter aux panels
		pnlProjet.add(btnCreer);
		pnlGlobal.add(lblLogo);
		pnlGlobal.add(pnlProjet);
		add(pnlGlobal);
	}

	//---------------------------------
	// METHODES
	//---------------------------------
	/**
	 * Ajouter un écouteur au bouton "Créer"
	 * @param ecouteur un ecouteur
	 */
	public void btnCreerClick(ActionListener ecouteur) {
		btnCreer.addActionListener(ecouteur);
	}

	/**
	 * Permet de redessiner la vue pour afficher les modifications
	 */
	public void Redessiner() {
		repaint();
	}

	/******************
	 ** ACCESSEURS **
	 ******************/
	/**
	 * Avoit le panel global
	 * @return le panel global
	 */
	public JPanel getPnlGlobal() {
		return pnlGlobal;
	}
	/**
	 * Modifier le panel globale
	 * @param pnlGlobal Le panel à ajouter
	 */
	public void setPnlGlobal(JPanel pnlGlobal) {
		this.pnlGlobal = pnlGlobal;
	}
}
