package Vues;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import Modeles.*;

/**
 * @author Cathy
 *
 *         La classe VueTableau est une vue qui affiche les informations dun
 *         Tableau.
 *         Elle permet également d'ajouter des écouteurs pour les actions de
 *         modification du tableau et d'ajout de liste.
 * 
 */

public class VueTableau extends JPanel {

	/******************
	 ** ATTRIBUTS **
	 ******************/
	private ModeleTableau tableau;
	private JLabel lblNomTableau;
	private JButton btnModifierTableau;
	private JButton btnAjouterListe;
	private JButton btnSupprimerTableau;
	public JPanel pnlPanneauTableau;

	/**********************
	 ** CONSTRUCTEUR **
	 **********************/

	/**
	 * Constructeur de la classe VueTableau.
	 * Crée une vue pour afficher les informations d'un tableau.
	 * 
	 * @param Tableau le tableau à afficher
	 */
	VueTableau(ModeleTableau Tableau) {
		// Mémoriser le modèle sur lequel ce panel est une vue
		this.tableau = Tableau;

		setLayout(new GridBagLayout());

		// Créer le panneau pour le titre du tableau
		JPanel pnlTitre = new JPanel(new GridBagLayout());
		lblNomTableau = new JLabel(tableau.getNomTableau().toUpperCase());
		lblNomTableau.setFont(new Font("Arial", Font.BOLD, 20)); // l'estetique du titre
		GridBagConstraints gbcTitre = new GridBagConstraints();
		gbcTitre.gridx = 0;
		gbcTitre.gridy = 0;
		gbcTitre.anchor = GridBagConstraints.NORTH;
		pnlTitre.add(lblNomTableau, gbcTitre);

		// Créer le boutton de modification de la tableau
		btnModifierTableau = new JButton("Modifier");
		// Créer le boutton pour Ajouter une liste
		btnAjouterListe = new JButton("Ajouter une liste");
		// Créer le boutton pour supprimer le tableau
		btnSupprimerTableau = new JButton("Supprimer");

		// Créer le panneau pour les bouton du tableau
		JPanel pnlBouton = new JPanel(new GridBagLayout());
		pnlBouton.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));

		GridBagConstraints gbcBouton = new GridBagConstraints();

		// Bouton modifier
		gbcBouton.gridx = 1;
		gbcBouton.gridy = 0;
		gbcBouton.insets = new Insets(0, 0, 0, 0);
		pnlBouton.add(btnModifierTableau, gbcBouton);

		// Bouton supprimer
		gbcBouton.gridx = 1;
		gbcBouton.gridy = 1;
		gbcBouton.insets = new Insets(0, 0, 0, 0);
		pnlBouton.add(btnSupprimerTableau, gbcBouton);

		// Bouton ajouter Liste
		gbcBouton.gridx = 1;
		gbcBouton.gridy = 2;
		gbcBouton.insets = new Insets(0, 0, 0, 0);
		pnlBouton.add(btnAjouterListe, gbcBouton);

		pnlPanneauTableau = new JPanel();

		// pour que les lignes se mette les une en desous des autres
		pnlPanneauTableau.setLayout(new BoxLayout(pnlPanneauTableau, BoxLayout.Y_AXIS));

		// Ajouter les sous-panneaux au panneau principal
		GridBagConstraints gbcPanneau = new GridBagConstraints();
		gbcPanneau.gridx = 0;
		gbcPanneau.gridy = 0;
		gbcPanneau.anchor = GridBagConstraints.PAGE_START; // indique que le composant doit être ancré en haut de la cellule
		gbcPanneau.anchor = GridBagConstraints.LINE_START; // indique que le composant doit être ancré à gauche de la
		// cellule
		pnlPanneauTableau.add(pnlTitre, gbcPanneau);

		gbcPanneau.gridx = 1;
		gbcPanneau.gridy = 0;
		pnlPanneauTableau.add(pnlBouton, gbcPanneau);

		// créer une bordure de trait noir et largeur minimale 1
		Border lineborder = BorderFactory.createLineBorder(Color.black, 1);

		// associer à un JPanel
		pnlPanneauTableau.setBorder(lineborder);
		add(pnlPanneauTableau);

	}

	/******************
	 ** METHODES **
	 ******************/
	/**
	 * Ajoute un écouteur pour l'action de cliquer sur le bouton "Modifier".
	 * 
	 * @param ecouteur l'écouteur à ajouter
	 */
	public void btnModifierTableauClick(ActionListener ecouteur) {
		btnModifierTableau.addActionListener(ecouteur);
	}

	/**
	 * Ajoute un écouteur pour l'action de cliquer sur le bouton "Ajouter une
	 * carte".
	 * 
	 * @param ecouteur l'écouteur à ajouter
	 */
	public void btnAjouterListeClick(ActionListener ecouteur) {
		btnAjouterListe.addActionListener(ecouteur);
	}

	/**
	 * Ajoute un écouteur pour l'action de cliquer sur le bouton "Supprimer".
	 *
	 * @param ecouteur l'écouteur à ajouter pour l'action de suppression
	 */
	public void btnSupprimerClick(ActionListener ecouteur) {
		btnSupprimerTableau.addActionListener(ecouteur);
	}

	/**
	 * Met à jour l'affichage de la vue du tableau avec les informations du tableau
	 * actuelle.
	 */
	public void updateVueTableau() {
		lblNomTableau.setText(tableau.getNomTableau().toUpperCase());
	}

}
